﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace MyClassLibrary
{
    public class RoleManager
    {
        List<Users> userList;
        string ConnectionString = "provider=Microsoft.ACE.OLEDB.16.0;Data Source=TeamDatabase.accdb;";

        public RoleManager()
        {
            userList = new List<Users>();
        }

        // This method will be used to open the relative form if the user is a coach
        public bool FindIfCoach(string userName)
        {
            foreach (Users users in userList)
            {
                if (users.UserName == userName && users.Title == "Coach")
                {
                    return true;
                }
            }
            return false;
        }

        // This method will be used to open the relative form if the user is a manager
        public bool FindIfManager(string userName)
        {
            foreach (Users users in userList)
            {
                if (users.UserName == userName && users.Title == "Manager")
                {
                    return true;
                }
            }
            return false;
        }

        // This method will be used to check if the username and password are correct
        public bool FindIfCredentialsValid(string userName, string password)
        {
            PopulateUsers();
            foreach (Users users in userList)
            {
                if (users.UserName == userName && users.Password == password)
                {
                    return true;
                }
            }

            return false;
        }

        // This method will populate the List with just the username, password, etc. from the database table Users

        public void PopulateUsers()
        {
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "SELECT clientUserName, clientPassword, clientFullName, clientTitle FROM Users";
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {

                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string userName = reader["clientUserName"].ToString();
                                string password = reader["clientPassword"].ToString();
                                string fullName = reader["clientFullName"].ToString();
                                string title = reader["clientTitle"].ToString();

                                Users user = new Users(userName, password, fullName, title);
                                userList.Add(user);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error" + ex.Message);
                    }
                }
            }

        }
    }
}
