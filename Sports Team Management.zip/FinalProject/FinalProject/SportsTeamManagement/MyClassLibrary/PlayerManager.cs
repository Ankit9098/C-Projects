﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MyClassLibrary
{
    public class PlayerManager
    {
        private List<Players> playersList;
        string ConnectionString = "provider=Microsoft.ACE.OLEDB.16.0;Data Source=TeamDatabase.accdb;";

        public PlayerManager()
        {
            playersList = new List<Players>();
        }

        public void AddPlayer(Players player)
        {
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "INSERT INTO Players (ID, PlayerName, PlayerAge, PlayerPosition, PlayerPG, PlayerPPG, PlayerAPG, PlayerRPG, PlayerSPG, PlayerTSM, PlayerTSA, PlayerTFTA, PlayerFTM, PlayerSP, PlayerFTP, PlayerImg) " +
                "VALUES (@ID, @PlayerName, @PlayerAge, @PlayerPosition, PlayerPG, @PlayerPPG, @PlayerAPG, @PlayerRPG, @PlayerSPG, @PlayerTSM, @PlayerTSA, @PlayerTFTA, PlayerFTM, @PlayerSP, @PlayerFTP, @PlayerImg)";

                //FullName, Age, Position, PPG, APG, RPG, SPG, TSA, TFTA, SP, FTP, ImgURL
                //    @FullName, @Age, @Position, @PPG, @APG, @RPG, @SPG, @TSA, @TFTA, @SP, @FTP, @ImgURL
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {
                        connection.Open();
                        command.Parameters.AddWithValue("@PlayerID", player.PlayerId);
                        command.Parameters.AddWithValue("@PlayerName", player.Name);
                        command.Parameters.AddWithValue("@PlayerAge", player.Age);
                        command.Parameters.AddWithValue("@PlayerPosition", player.Position);
                        command.Parameters.AddWithValue("@PlayerPG", player.GamesPlayed);
                        command.Parameters.AddWithValue("@PlayerPPG", player.PointsPerGame);
                        command.Parameters.AddWithValue("@PlayerAPG", player.AssistsPerGame);
                        command.Parameters.AddWithValue("@PlayerRPG", player.ReboundsPerGame);
                        command.Parameters.AddWithValue("@PlayerSPG", player.StealsPerGame);
                        command.Parameters.AddWithValue("@PlayerTSM", player.TotalShotsMade);
                        command.Parameters.AddWithValue("@PlayerTSA", player.TotalShotsAttempted);
                        command.Parameters.AddWithValue("@PlayerTFTA", player.TotalFreeThrowsAttempted);
                        command.Parameters.AddWithValue("@PlayerFTM", player.FreeThrowsMade);
                        command.Parameters.AddWithValue("@PlayerSP", player.ShootingPercentage);
                        command.Parameters.AddWithValue("@PlayerFTP", player.FreeThrowPercentage);
                        command.Parameters.AddWithValue("@PlayerImg", player.ImageUrl);

                        command.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }


        public void DeletePlayer(int playerID)
        {
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string deleteStatement = "DELETE FROM Players WHERE ID = @playerID";
                try
                {
                    connection.Open();
                    using (OleDbCommand command = new OleDbCommand(deleteStatement, connection))
                    {
                        command.Parameters.AddWithValue("@playerID", playerID);
                        command.ExecuteNonQuery();
                    }

                    MessageBox.Show("Deleted");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    MessageBox.Show("error" + ex);
                }
            }
        }

        public List<Players> ViewPlayerDatabase()
        {
            List<Players> crs = new List<Players>();
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "SELECT ID, PlayerName, PlayerAge, PlayerPosition FROM Players";
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {

                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var playerID = int.Parse(reader["ID"].ToString());
                                var PlayerName = reader["PlayerName"].ToString();
                                var PlayerAge = int.Parse(reader["PlayerAge"].ToString());
                                var PlayerPosition = reader["PlayerPosition"].ToString();

                                Players players = new Players(playerID, PlayerName, PlayerAge,
                                PlayerPosition);
                                crs.Add(players);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error" + ex.Message);
                    }
                }

                return crs;
            }
        }

        public void UpdatePlayer(int playerID, string name, int age, string position, int gamesPlayed, double pointsPerGame, double assistsPerGame, double reboundsPerGame, double stealsPerGame, int totalShotsMade,
            int totalShotsAttempted, int totalFreeThrowsAttempted, int freeThrowsMade, double shootingPercentage, double freeThrowsPercentage, string imageURL)
        {
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string updateStatement = "UPDATE Players SET " +
                                         "ID = @PlayerID, PlayerName = @PlayerName, PlayerAge = @PlayerAge, PlayerPosition = @PlayerPosition, PlayerPG = @PlayerPG, PlayerPPG = @PlayerPPG, PlayerAPG = @PlayerAPG, PlayerRPG = @PlayerRPG, PlayerSPG = @PlayerSPG, PlayerTSM = @PlayerTSM, " +
                                         "PlayerTSA = @PlayerTSA, PlayerTFTA = @PlayerTFTA, PlayerFTM = @PlayerFTM, PlayerSP = @PlayerSP, PlayerFTP = @PlayerFTP, PlayerImg = @PlayerImg WHERE ID = @PlayerID";
                using (OleDbCommand command = new OleDbCommand(updateStatement, connection))
                {
                    // Adding parameters to the command
                    command.Parameters.AddWithValue("@PlayerID", playerID);
                    command.Parameters.AddWithValue("@PlayerName", name);
                    command.Parameters.AddWithValue("@PlayerAge", age);
                    command.Parameters.AddWithValue("@PlayerPosition", position);
                    command.Parameters.AddWithValue("@PlayerPG", gamesPlayed);
                    command.Parameters.AddWithValue("@PlayerPPG", pointsPerGame);
                    command.Parameters.AddWithValue("@PlayerAPG", assistsPerGame);
                    command.Parameters.AddWithValue("@PlayerRPG", reboundsPerGame);
                    command.Parameters.AddWithValue("@PlayerSPG", stealsPerGame);
                    command.Parameters.AddWithValue("@PlayerTSM", totalShotsMade);
                    command.Parameters.AddWithValue("@PlayerTSA", totalShotsAttempted);
                    command.Parameters.AddWithValue("@PlayerTFTA", totalFreeThrowsAttempted);
                    command.Parameters.AddWithValue("@PlayerFTM", freeThrowsMade);
                    command.Parameters.AddWithValue("@PlayerSP", shootingPercentage);
                    command.Parameters.AddWithValue("@PlayerFTP", freeThrowsPercentage);
                    command.Parameters.AddWithValue("@PlayerImg", imageURL);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Changes have been made.");
                        }
                        else
                        {
                            MessageBox.Show("No changes made. Check your Code.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        public List<Players> SearchPlayersDatabaseByPlayerID(int playerID)
        {
            List<Players> selectedCourse = new List<Players>();
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "SELECT * FROM Players WHERE ID = @playerID";
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    command.Parameters.AddWithValue("@playerID", playerID);
                    try
                    {

                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int id = int.Parse(reader["ID"].ToString());
                                string name = reader["PlayerName"].ToString();
                                int age = int.Parse(reader["PlayerAge"].ToString());
                                string position = reader["PlayerPosition"].ToString();
                                int gamesPlayed = int.Parse(reader["PlayerPG"].ToString());
                                double pointsPerGame = double.Parse(reader["PlayerPPG"].ToString());
                                double assistsPerGame = double.Parse(reader["PlayerAPG"].ToString());
                                double reboundsPerGame = double.Parse(reader["PlayerRPG"].ToString());
                                double stealsPerGame = double.Parse(reader["PlayerSPG"].ToString());
                                int totalShotsMade = int.Parse(reader["PlayerTSM"].ToString());
                                int totalShotsAttempted = int.Parse(reader["PlayerTSA"].ToString());
                                int totalFreeThrowsAttempted = int.Parse(reader["PlayerTFTA"].ToString());
                                int freeThrowsMade = int.Parse(reader["PlayerFTM"].ToString());
                                double shootingPercentage = double.Parse(reader["PlayerSP"].ToString());
                                double freeThrowsPercentage = double.Parse(reader["PlayerFTP"].ToString());
                                string imageURL = reader["PlayerImg"].ToString();

                                Players players = new Players(id, name, age, position, gamesPlayed, pointsPerGame,
                                    assistsPerGame, reboundsPerGame, stealsPerGame, totalShotsMade, totalShotsAttempted,
                                    totalFreeThrowsAttempted, freeThrowsMade, shootingPercentage, freeThrowsPercentage, imageURL);
                                selectedCourse.Add(players);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error" + ex.Message);
                    }
                }

                return selectedCourse;
            }
        }

        public List<Players> GetAllPlayers()
        {
            List<Players> selectedCourse = new List<Players>();
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "SELECT * FROM Players";
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {

                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int id = int.Parse(reader["ID"].ToString());
                                string name = reader["PlayerName"].ToString();
                                int age = int.Parse(reader["PlayerAge"].ToString());
                                string position = reader["PlayerPosition"].ToString();
                                int gamesPlayed = int.Parse(reader["PlayerPG"].ToString());
                                double pointsPerGame = double.Parse(reader["PlayerPPG"].ToString());
                                double assistsPerGame = double.Parse(reader["PlayerAPG"].ToString());
                                double reboundsPerGame = double.Parse(reader["PlayerRPG"].ToString());
                                double stealsPerGame = double.Parse(reader["PlayerSPG"].ToString());
                                int totalShotsMade = int.Parse(reader["PlayerTSM"].ToString());
                                int totalShotsAttempted = int.Parse(reader["PlayerTSA"].ToString());
                                int totalFreeThrowsAttempted = int.Parse(reader["PlayerTFTA"].ToString());
                                int freeThrowsMade = int.Parse(reader["PlayerFTM"].ToString());
                                double shootingPercentage = double.Parse(reader["PlayerSP"].ToString());
                                double freeThrowsPercentage = double.Parse(reader["PlayerFTP"].ToString());
                                string imageURL = reader["PlayerImg"].ToString();

                                Players players = new Players(id, name, age, position, gamesPlayed, pointsPerGame,
                                    assistsPerGame, reboundsPerGame, stealsPerGame, totalShotsMade, totalShotsAttempted,
                                    totalFreeThrowsAttempted, freeThrowsMade, shootingPercentage, freeThrowsPercentage, imageURL);
                                selectedCourse.Add(players);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error" + ex.Message);
                    }
                }

                return selectedCourse;
            }
        }

        public double FindAllRPGCarerrStas(int PlayerID)
        {
            double carrerRPG = 0.0;
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "SELECT PlayerPG, PlayerPPG, PlayerAPG, PlayerRPG FROM Players WHERE ID = " + PlayerID;
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {

                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int gamesPlayed = int.Parse(reader["PlayerPG"].ToString());
                                double pointsPerGame = double.Parse(reader["PlayerPPG"].ToString());
                                double assistsPerGame = double.Parse(reader["PlayerAPG"].ToString());
                                double reboundsPerGame = double.Parse(reader["PlayerRPG"].ToString());

                                carrerRPG = reboundsPerGame * gamesPlayed;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error" + ex.Message);
                    }
                }

                return carrerRPG;
            }
        }

        public double FindAllAPGCarerrStas(int PlayerID)
        {
            double carrerAPG = 0.0;
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "SELECT PlayerPG, PlayerAPG FROM Players WHERE ID = " + PlayerID;
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {

                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int gamesPlayed = int.Parse(reader["PlayerPG"].ToString());
                                double assistsPerGame = double.Parse(reader["PlayerAPG"].ToString());

                                carrerAPG = assistsPerGame * gamesPlayed;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error" + ex.Message);
                    }
                }

                return carrerAPG;
            }
        }

        public double FindAllPPGCarerrStas(int PlayerID)
        {
            double carrerPPG = 0.0;
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "SELECT PlayerPG, PlayerPPG FROM Players WHERE ID = " + PlayerID;
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {

                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int gamesPlayed = int.Parse(reader["PlayerPG"].ToString());
                                double pointsPerGame = double.Parse(reader["PlayerPPG"].ToString());


                                carrerPPG = pointsPerGame * gamesPlayed;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error" + ex.Message);
                    }
                }

                return carrerPPG;
            }
        }

        // This method will take category that must match the player table and provide it a int like top 5, 10 and it will created a list with that speicifced category and the count.
        public List<Players> GetTopPlayersInCategory(string category, int topValue)
        {
            List<Players> topPlayers = new List<Players>();
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string query = "SELECT * FROM Players ORDER BY " + category + " DESC";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            int count = 0;
                            while (reader.Read() && count < topValue)
                            {
                                int id = int.Parse(reader["ID"].ToString());
                                string name = reader["PlayerName"].ToString();
                                int age = int.Parse(reader["PlayerAge"].ToString());
                                string position = reader["PlayerPosition"].ToString();
                                int gamesPlayed = int.Parse(reader["PlayerPG"].ToString());
                                double pointsPerGame = double.Parse(reader["PlayerPPG"].ToString());
                                double assistsPerGame = double.Parse(reader["PlayerAPG"].ToString());
                                double reboundsPerGame = double.Parse(reader["PlayerRPG"].ToString());
                                double stealsPerGame = double.Parse(reader["PlayerSPG"].ToString());
                                int totalShotsMade = int.Parse(reader["PlayerTSM"].ToString());
                                int totalShotsAttempted = int.Parse(reader["PlayerTSA"].ToString());
                                int totalFreeThrowsAttempted = int.Parse(reader["PlayerTFTA"].ToString());
                                int freeThrowsMade = int.Parse(reader["PlayerFTM"].ToString());
                                double shootingPercentage = double.Parse(reader["PlayerSP"].ToString());
                                double freeThrowsPercentage = double.Parse(reader["PlayerFTP"].ToString());
                                string imageURL = reader["PlayerImg"].ToString();
                                Players player = new Players(id, name, age, position, gamesPlayed, pointsPerGame, assistsPerGame, reboundsPerGame, stealsPerGame, totalShotsMade, totalShotsAttempted, totalFreeThrowsAttempted, freeThrowsMade, shootingPercentage, freeThrowsPercentage, imageURL);
                                topPlayers.Add(player);
                                count++;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error" + ex.Message);
                    }
                }
            }
            return topPlayers;
        }

        

        public List<Players> FilterByPosition(List<Players> unsortedPlayersList, string position)
        {
            List<Players> filteredPlayers = new List<Players>();
            foreach (Players players in unsortedPlayersList)
            {
                if (players.Position == position)
                {
                    filteredPlayers.Add(players);
                }
            }
            return filteredPlayers;
        }

    }
}
