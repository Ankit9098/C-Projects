﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClassLibrary
{
    public class Team
    {
        private int teamID;
        private string teamName;
        private string teamHomeCity;
        private string teamLogoUrl;
        public Team()
        {
        }

        public Team(string teamName)
        {
            this.teamName = teamName;
        }

        public Team(int teamID, string teamName, string teamLogoUrl)
        {
            this.teamID = teamID;
            this.teamName = teamName;
            this.teamLogoUrl = teamLogoUrl;
        }

        public Team(int teamID, string teamName, string teamHomeCity, string teamLogoUrl)
        {
            this.teamID = teamID;
            this.teamName = teamName;
            this.teamHomeCity = teamHomeCity;
            this.teamLogoUrl = teamLogoUrl;
        }

        public int TeamID
        {
            get { return this.teamID; }
            set { this.teamID = value; }
        }

        public string TeamName
        {
            get { return this.teamName; } set { this.teamName = value; }

        }


        public string TeamHomeCity
        {
            get { return this.teamHomeCity; }
            set { this.teamHomeCity = value;}
        }

        public string TeamLogoUrl
        {
            get { return this.teamLogoUrl;}
            set { this.teamLogoUrl = value;}
        }
    }
}
