﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;

namespace MyClassLibrary
{
    public class TeamManager
    {
        private List<Team> teamCreated;
        string ConnectionString = "provider=Microsoft.ACE.OLEDB.16.0;Data Source=TeamDatabase.accdb;";
        public TeamManager()
        {
            teamCreated = new List<Team>();
        }

        public bool AddTeamInDatabase(Team team)
        {
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "INSERT INTO Teams (TeamID, TeamName, TeamHomeCity, TeamLogo) " +
                "VALUES (@TeamID, @TeamName, @TeamHomeCity, @Logo)";

                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {
                        connection.Open();
                        command.Parameters.AddWithValue("@TeamID", team.TeamID);
                        command.Parameters.AddWithValue("@TeamName", team.TeamName);
                        command.Parameters.AddWithValue("@TeamHomeCity", team.TeamHomeCity);
                        command.Parameters.AddWithValue("@Logo", team.TeamLogoUrl);

                        command.ExecuteNonQuery();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                        return false;
                    }
                }
            }
        }

        public List<Team> GetAllTeamsInDatabase()
        {
            List<Team> teams = new List<Team>();

            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement = "SELECT * FROM Teams";

                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    connection.Open();

                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int teamID = int.Parse(reader["TeamID"].ToString());
                            string teamName = reader["TeamName"].ToString();
                            string imgUrl = reader["TeamLogo"].ToString();
                            Team team = new Team(teamID, teamName, imgUrl);

                            teams.Add(team);
                        }
                    }
                }
            }

            return teams;
        }


        public void DeletePlayersFromTeam(int playerID)
        {
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string deleteStatement = "DELETE FROM teamPlayers WHERE ID = @playerID";
                try
                {
                    connection.Open();
                    using (OleDbCommand command = new OleDbCommand(deleteStatement, connection))
                    {
                        command.Parameters.AddWithValue("@playerID", playerID);
                        command.ExecuteNonQuery();
                    }

                    MessageBox.Show("Deleted");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    MessageBox.Show("error" + ex);
                }
            }
        }

        
        public List<String> ViewAllTeamsInDatabase()
        {
            List<String> savedTeams = new List<String>();
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "SELECT TeamName FROM Teams";
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {

                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var teamNames = reader["TeamName"].ToString();

                                savedTeams.Add(teamNames);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error" + ex.Message);
                    }
                }

                return savedTeams;
            }
        }

        public string FindTeamLogo(int teamID)
        {
            string logoUrl = "";
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement = "SELECT TeamLogo " +
                                         "FROM Teams " +
                                         "WHERE TeamID = " + teamID;

                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {
                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                logoUrl = reader["TeamLogo"].ToString();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }

            return logoUrl;
        }

        public void UpdateTeams(int teamID, string teamName, string teamHomeCity, string logoUrl)
        {
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string updateStatement = "UPDATE Teams SET " +
                                         "TeamName = @TeamName, TeamHomeCity = @TeamHomeCity, TeamLogo = @Logo" +
                                         "WHERE TeamID = @Id";
                using (OleDbCommand command = new OleDbCommand(updateStatement, connection))
                {
                    // Adding parameters to the command
                    command.Parameters.AddWithValue("@TeamName", teamName);
                    command.Parameters.AddWithValue("@TeamHomeCity", teamHomeCity);
                    command.Parameters.AddWithValue("@Logo", logoUrl);
                    command.Parameters.AddWithValue("@Id", teamID);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Changes have been made.");
                        }
                        else
                        {
                            MessageBox.Show("No changes made. Check your Code.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        public List<Players> GetPlayersForTeam(int teamID)
        {
            List<Players> playersList = new List<Players>();
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement = "SELECT Players.ID, PlayerName, PlayerAge, PlayerPosition, PlayerPG, PlayerPPG, PlayerAPG, PlayerRPG, PlayerSPG, PlayerTSM, PlayerTSA, PlayerTFTA, PlayerFTM, PlayerSP, PlayerFTP, PlayerImg " +
                               "FROM Players " +
                               "INNER JOIN teamPlayers ON Players.ID = teamPlayers.ID " +
                               "WHERE teamPlayers.TeamID = " + teamID;

                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {
                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int id = int.Parse(reader["ID"].ToString());
                                string name = reader["PlayerName"].ToString();
                                int age = int.Parse(reader["PlayerAge"].ToString());
                                string position = reader["PlayerPosition"].ToString();
                                int gamesPlayed = int.Parse(reader["PlayerPG"].ToString());
                                double pointsPerGame = double.Parse(reader["PlayerPPG"].ToString());
                                double assistsPerGame = double.Parse(reader["PlayerAPG"].ToString());
                                double reboundsPerGame = double.Parse(reader["PlayerRPG"].ToString());
                                double stealsPerGame = double.Parse(reader["PlayerSPG"].ToString());
                                int totalShotsMade = int.Parse(reader["PlayerTSM"].ToString());
                                int totalShotsAttempted = int.Parse(reader["PlayerTSA"].ToString());
                                int totalFreeThrowsAttempted = int.Parse(reader["PlayerTFTA"].ToString());
                                int freeThrowsMade = int.Parse(reader["PlayerFTM"].ToString());
                                double shootingPercentage = double.Parse(reader["PlayerSP"].ToString());
                                double freeThrowsPercentage = double.Parse(reader["PlayerFTP"].ToString());
                                string imageURL = reader["PlayerImg"].ToString();

                                Players players = new Players(id, name, age, position, gamesPlayed, pointsPerGame,
                                    assistsPerGame, reboundsPerGame, stealsPerGame, totalShotsMade, totalShotsAttempted,
                                    totalFreeThrowsAttempted, freeThrowsMade, shootingPercentage, freeThrowsPercentage, imageURL);

                                playersList.Add(players);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
            return playersList;
        }

        public int GetTeamID(string teamName)
        {
            int teamID = 0;
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "SELECT TeamID FROM Teams WHERE TeamName = @teamName";
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    command.Parameters.AddWithValue("@teamName", teamName);
                    try
                    {

                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var id = int.Parse(reader["TeamID"].ToString());
                                teamID = id;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error" + ex.Message);
                    }
                }

                return teamID;
            }
        }


        public bool AddPlayerInTeam(int teamID, int playerID)
        {
            if (!CanAddPlayerToTeam(teamID))
            {
                // If the team is full or an error occurs stop.
                return false;
            }
            bool isInAnyTeam = IsPlayerInAnyTeam(playerID);
            if (isInAnyTeam)
            {
                MessageBox.Show("Player is already in a team.");
                return false; // Prevent adding the player to another team
            }

            bool isInSpecificTeam = IsPlayerInSpecificTeam(playerID, teamID);
            if (isInSpecificTeam)
            {
                MessageBox.Show("Player is already in the specific team.");
                return false; // Prevent adding the player again to the same team
            }

            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement = "INSERT INTO teamPlayers (TeamID, ID) VALUES (@TeamID, @PlayerID)";
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {
                        connection.Open();
                        command.Parameters.AddWithValue("@TeamID", teamID);
                        command.Parameters.AddWithValue("@PlayerID", playerID);

                        command.ExecuteNonQuery();
                        MessageBox.Show("Player successfully added to the team.");
                        return true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                        return false;
                    }
                }
            }
        }


        // Created a  method checks if a particular player (by playerID) is already in a specific team (by teamID).
        public bool IsPlayerInSpecificTeam(int playerID, int teamID)
        {
            // establishing a connection to the database using a predefined connection string.
            // using makes sure that a connection is properly closed
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                //  wrote an SQL query that counts as an alias the number of rows in the teamPlayers table where the player ID and team ID are same
                string insertStatement = "SELECT COUNT(*) AS PlayerCount FROM teamPlayers WHERE ID = @PlayerID AND TeamID = @TeamID";
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    command.Parameters.AddWithValue("@PlayerID", playerID);
                    command.Parameters.AddWithValue("@TeamID", teamID);

                    try
                    {
                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Gets the number of times this player is linked to same team.
                                int count = int.Parse(reader["PlayerCount"].ToString());
                                return count > 0;
                            }
                            return false;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                        return false;
                    }
                }
            }
        }

        public bool IsPlayerInAnyTeam(int playerID)
        {
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement = "SELECT COUNT(*) AS PlayerCount FROM teamPlayers WHERE ID = @PlayerID";
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    command.Parameters.AddWithValue("@PlayerID", playerID);

                    try
                    {
                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int count = int.Parse(reader["PlayerCount"].ToString());
                                return count > 0;
                            }
                            return false;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                        return false;
                    }
                }
            }
        }

        public bool CanAddPlayerToTeam(int teamID)
        {
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement = "SELECT COUNT(*) AS PlayerCount FROM teamPlayers WHERE TeamID = @TeamID";
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    command.Parameters.AddWithValue("@TeamID", teamID);
                    try
                    {
                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int numberOfPlayers = int.Parse(reader["PlayerCount"].ToString());
                                if (numberOfPlayers >= 15)
                                {
                                    MessageBox.Show("The team already has 15 players.");
                                    // Team is full, cannot add more players
                                    return false;
                                }
                                // Team has less than 15 players, can add more players
                                return true;
                            }
                            // No record read, unexpected
                            return false;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error checking team size: " + ex.Message);
                        // Error occurred, just making an assumuption that cannot add more players
                        return false;
                    }
                }
            }
        }







    }
}
