﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyClassLibrary
{
    public class GameScheduleManager
    {
        string ConnectionString = "provider=Microsoft.ACE.OLEDB.16.0;Data Source=TeamDatabase.accdb;";
        public GameScheduleManager()
        {

        }

        public bool AddVenue(gameSchedule game)
        {
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "INSERT INTO Games (VenueID, GameDate, HomeTeam, AwayTeam) " +
                    "VALUES (@VenueID, @GameDate, @HomeTeam, @AwayTeam)";

                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {
                        connection.Open();
                        command.Parameters.AddWithValue("@VenueID", game.VenueID);
                        command.Parameters.AddWithValue("@GameDate", game.GameDate);
                        command.Parameters.AddWithValue("@HomeTeam", game.HomeTeam);
                        command.Parameters.AddWithValue("@AwayTeam", game.AwayTeam);

                        command.ExecuteNonQuery();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                        return false;
                    }
                }
            }
        }

        public bool UpdateVenue(gameSchedule game)
        {
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string updateStatement =
                    "UPDATE Games SET VenueID = @VenueID, GameDate = @GameDate, HomeTeam = @HomeTeam, AwayTeam = @AwayTeam, HomeScore = @HomeScore, AwayScore = @AwayScore " +
                    "WHERE VenueID = @VenueID";

                using (OleDbCommand command = new OleDbCommand(updateStatement, connection))
                {
                    try
                    {
                        connection.Open();

                        command.Parameters.AddWithValue("@VenueID", game.VenueID);
                        command.Parameters.AddWithValue("@GameDate", game.GameDate);
                        command.Parameters.AddWithValue("@HomeTeam", game.HomeTeam);
                        command.Parameters.AddWithValue("@AwayTeam", game.AwayTeam);
                        command.Parameters.AddWithValue("@HomeScore", game.HomeScore);
                        command.Parameters.AddWithValue("@AwayScore", game.AwayScore);

                        command.ExecuteNonQuery();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                        return false;
                    }
                }
            }
        }

        public List<gameSchedule> GetGames()
        {
            List<gameSchedule> games = new List<gameSchedule>();

            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement = "SELECT * FROM Games";

                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {
                        connection.Open();

                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int venueID = int.Parse(reader["VenueID"].ToString());
                                DateTime gameDate = (DateTime)reader["GameDate"];
                                string homeTeam = reader["HomeTeam"].ToString();
                                string awayTeam = reader["AwayTeam"].ToString();
                                double homeScore = double.Parse(reader["HomeScore"].ToString());
                                double awayScore = double.Parse(reader["AwayScore"].ToString());

                                gameSchedule game = new gameSchedule(venueID, gameDate, homeTeam, awayTeam, homeScore, awayScore);
                                games.Add(game);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }

            return games;
        }


        public List<gameSchedule> GetSelectedVenue(int venueID)
        {
            List<gameSchedule> games = new List<gameSchedule>();

            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement = "SELECT * FROM Games WHERE VenueID = @ID";

                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {
                        connection.Open();
                        command.Parameters.AddWithValue("@ID", venueID);

                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int ID = int.Parse(reader["VenueID"].ToString());
                                DateTime gameDate = (DateTime)reader["GameDate"];
                                string homeTeam = reader["HomeTeam"].ToString();
                                string awayTeam = reader["AwayTeam"].ToString();
                                double homeScore = double.Parse(reader["HomeScore"].ToString());
                                double awayScore = double.Parse(reader["AwayScore"].ToString());

                                gameSchedule game = new gameSchedule(ID, gameDate, homeTeam, awayTeam, homeScore, awayScore);
                                games.Add(game);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }

            return games;
        }
    }
}
