﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace MyClassLibrary
{
    public class UserManager
    {
        string ConnectionString = "provider=Microsoft.ACE.OLEDB.16.0;Data Source=TeamDatabase.accdb;";

        public UserManager()
        {

        }

        public bool AddUserIntoDatabase(Users user)
        {
            if (IsUserSavedInDatabase(user.UserName))
            {
                MessageBox.Show("User already exists. Please use a different username.");
                return false;
            }
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement =
                    "INSERT INTO Users (clientUserName, clientPassword, clientFullName, clientTitle) " +
                    "VALUES (@userName, @password, @fullName, @title)";
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    try
                    {
                        connection.Open();
                        command.Parameters.AddWithValue("@userName", user.UserName);
                        command.Parameters.AddWithValue("@password", user.Password);
                        command.Parameters.AddWithValue("@fullName", user.FullName);
                        command.Parameters.AddWithValue("@title", user.Title);
                        command.ExecuteNonQuery();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error" + ex.Message);
                        return false;
                    }
                }
            }
        }

        public bool IsUserSavedInDatabase(string userName)
        {
            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string insertStatement = "SELECT COUNT(*) AS UserCount FROM Users WHERE clientUserName = @userName";
                using (OleDbCommand command = new OleDbCommand(insertStatement, connection))
                {
                    command.Parameters.AddWithValue("@userName", userName);

                    try
                    {
                        connection.Open();
                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int count = int.Parse(reader["UserCount"].ToString());
                                return count > 0;
                            }
                            return false;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                        return false;
                    }
                }
            }
        }



    }
}
