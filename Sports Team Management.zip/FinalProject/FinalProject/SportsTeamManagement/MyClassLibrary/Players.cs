﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClassLibrary
{
    public class Players
    {
        public enum BasketballPosition
        {
            Guard,
            Forward,
            Center

        }

        public enum Categories
        {
            PlayerPPG,
            PlayerAPG,
            PlayerRPG
        }

        private int playerId;
        private string name;
        private int age;
        private string position;
        private int gamesPlayed;
        private double pointsPerGame;
        private double assistsPerGame;
        private double reboundsPerGame;
        private double stealsPerGame;
        private int totalShotsAttempted;
        private int totalShotsMade;
        private int totalFreeThrowsAttempted;
        private int freeThrowsMade;  // This should be explicitly tracked
        private double shootingPercentage;
        private double freeThrowPercentage;
        private string imageURL;

        // Constructors
        public Players()
        {

        }

        public Players(int playerId, string name, int age, string position)
        {
            this.playerId = playerId;
            this.name = name;
            this.age = age;
            this.position = position;
        }

        

        public Players(int playerId, string name, int age, string position, int gamesPlayed,
        double pointsPerGame, double assistsPerGame, double reboundsPerGame, double stealsPerGame, int totalShotsMade,
            int totalShotsAttempted, int totalFreeThrowsAttempted, int freeThrowsMade, double shootingPercentage, double freeThrowPercentage, string imageURL)
        {
            this.playerId = playerId;
            this.name = name;
            this.age = age;
            this.position = position;
            this.gamesPlayed = gamesPlayed;
            this.pointsPerGame = pointsPerGame;
            this.assistsPerGame = assistsPerGame;
            this.reboundsPerGame = reboundsPerGame;
            this.stealsPerGame = stealsPerGame;
            this.totalShotsMade = totalShotsMade;
            this.totalShotsAttempted = totalShotsAttempted;
            this.totalFreeThrowsAttempted = totalFreeThrowsAttempted;
            this.freeThrowsMade = freeThrowsMade;
            this.shootingPercentage = shootingPercentage;
            this.freeThrowPercentage = freeThrowPercentage;
            this.imageURL = imageURL;
            CalculateShootingPercentage();  // Calculate on initialization
            CalculateFreeThrowPercentage();  // Calculate on initialization
        }

        public Players(int playerId, string name, int age, string position, int gamesPlayed,
        double pointsPerGame, double assistsPerGame, double reboundsPerGame, double stealsPerGame, int totalShotsMade,
            int totalShotsAttempted, int totalFreeThrowsAttempted, int freeThrowsMade, string imageURL)
        {
            this.playerId = playerId;
            this.name = name;
            this.age = age;
            this.position = position;
            this.gamesPlayed = gamesPlayed;
            this.pointsPerGame = pointsPerGame;
            this.assistsPerGame = assistsPerGame;
            this.reboundsPerGame = reboundsPerGame;
            this.stealsPerGame = stealsPerGame;
            this.totalShotsMade = totalShotsMade;
            this.totalShotsAttempted = totalShotsAttempted;
            this.totalFreeThrowsAttempted = totalFreeThrowsAttempted;
            this.freeThrowsMade = freeThrowsMade;
            this.imageURL = imageURL;
            CalculateShootingPercentage();  // Calculate on initialization
            CalculateFreeThrowPercentage();  // Calculate on initialization
        }


        // Property declarations with basic get and set
        public int PlayerId
        {
            get { return playerId; }
            set { playerId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Age
        {
            get { return age; }
            set
            {
                if (value < 0)
                    throw new ArgumentException("Age cannot be negative");
                age = value;
            }
        }


        public string Position
        {
            get { return position; }
            set { position = value; }
        }

        public int GamesPlayed
        {
            get { return gamesPlayed; }
            set { gamesPlayed = value; }
        }
        public double PointsPerGame
        {
            get { return pointsPerGame; }
            set
            {
                pointsPerGame = value;
                CalculateShootingPercentage();
            }
        }

        public double AssistsPerGame
        {
            get { return assistsPerGame; }
            set
            {
                assistsPerGame = value;
                CalculateFreeThrowPercentage();
            }
        }

        public double ReboundsPerGame
        {
            get { return reboundsPerGame; }
            set { reboundsPerGame = value; }
        }

        public double StealsPerGame
        {
            get { return stealsPerGame; }
            set { stealsPerGame = value; }
        }

        public int TotalShotsMade
        {
            get { return totalShotsMade; }
            set { totalShotsMade = value; }
        }
        public int TotalShotsAttempted
        {
            get { return totalShotsAttempted; }
            set
            {
                totalShotsAttempted = value;
                CalculateShootingPercentage();
            }
        }

        public int TotalFreeThrowsAttempted
        {
            get { return totalFreeThrowsAttempted; }
            set
            {
                totalFreeThrowsAttempted = value;
                CalculateFreeThrowPercentage();
            }
        }

        public int FreeThrowsMade
        {
            get { return freeThrowsMade; }
            set { freeThrowsMade = value; }
        }

        public double ShootingPercentage
        {
            get { return shootingPercentage; }
        }

        public double FreeThrowPercentage
        {
            get { return freeThrowPercentage; }
        }

        private void CalculateShootingPercentage()
        {
            if (totalShotsAttempted > 0)
                shootingPercentage = (totalShotsMade / totalShotsAttempted) * 100;
            else
                shootingPercentage = 0;
        }

        private void CalculateFreeThrowPercentage()
        {
            if (totalFreeThrowsAttempted > 0)
                freeThrowPercentage = (freeThrowsMade / (double)totalFreeThrowsAttempted) * 100;
            else
                freeThrowPercentage = 0;
        }

        

        public string ImageUrl
        {
            get { return imageURL; }
            set { imageURL = value; }
        }
    }
}
