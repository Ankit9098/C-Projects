﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClassLibrary
{
    public class gameSchedule
    {
        private int venueID;
        private DateTime gameDate;
        private string homeTeam;
        private string awayTeam;
        private double homeScore;
        private double awayScore;

        public gameSchedule() { }

        public gameSchedule(int venueID, DateTime gameDate, string homeTeam, string awayTeam)
        {
            this.venueID = venueID;
            this.gameDate = gameDate;
            this.homeTeam = homeTeam;
            this.awayTeam = awayTeam;
        }

        public gameSchedule(int venueID, DateTime gameDate, string homeTeam, string awayTeam, double homeScore, double awayScore)
        {
            this.venueID = venueID;
            this.gameDate = gameDate;
            this.homeTeam = homeTeam;
            this.awayTeam = awayTeam;
            this.homeScore = homeScore;
            this.awayScore = awayScore;
        }

        public int VenueID
        {
            get { return venueID; }
            set { venueID = value; }
        }

        public DateTime GameDate
        {
            get { return gameDate; }
            set { gameDate = value; }
        }

        public string HomeTeam
        {
            get { return homeTeam; }
            set { homeTeam = value; }
        }

        public string AwayTeam
        {
            get { return awayTeam; }
            set { awayTeam = value; }
        }

        public double HomeScore
        {
            get { return homeScore; }
            set { homeScore = value; }
        }

        public double AwayScore
        {
            get {
                return awayScore;
            }
            set {
                awayScore = value;
            }
        }
    }
}
