﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClassLibrary
{
    public class Users
    {
        private string userName;
        private string password;
        private string fullName;
        private string firstName;
        private string lastName;

        public enum AccessLevel
        {
            Coach,
            Manager
        }

        private string title;

        public Users()
        {
        }

        public Users(string userName, string password, string fullName, string title)
        {
            this.userName = userName;
            this.password = password;
            this.fullName = fullName;
            this.title = title;
        }

        public Users(string userName, string password, string firstName, string lastName, string title)
        {
            this.userName = userName;
            this.password = password;
            this.firstName = firstName;
            this.lastName = lastName;
            this.title = title;
        }

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        // Using an interpolated string to join the firstName and lastName
        public string FullName
        {
            get { return $"{firstName}, {lastName}"; }
        }

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        // Using an interpolated string to join the fullName and title
        public override string ToString()
        {
            return $"{fullName} is logged as a {title}";
        }
    }
}