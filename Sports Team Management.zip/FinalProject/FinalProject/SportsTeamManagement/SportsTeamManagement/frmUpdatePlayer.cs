﻿using MyClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportsTeamManagement
{
    public partial class frmUpdatePlayer : Form
    {
        private frmPlayerManagement ownerForm;
        Players player;
        PlayerManager playerManager = new PlayerManager();

        public frmUpdatePlayer()
        {
            InitializeComponent();
        }
        public void SetOwner(Form theForm)
        {
            // Cast the form to the correct class.
            ownerForm = (frmPlayerManagement)theForm;
        }

        private void frmUpdatePlayer_Load(object sender, EventArgs e)
        {
            cmbPosition.DataSource = Enum.GetValues(typeof(Players.BasketballPosition));
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtPlayerID.Text);
            string name = txtName.Text;
            int age = int.Parse(txtAge.Text);
            string position = cmbPosition.SelectedItem.ToString();
            int gamesPlayed = int.Parse(txtGamesPlayed.Text);
            double pointsPerGame = double.Parse(txtPPG.Text);
            double assistsPerGame = double.Parse(txtAPG.Text);
            double reboundsPerGame = double.Parse(txtRPG.Text);
            double stealsPerGame = double.Parse(txtSPG.Text);
            int totalShotsMade = int.Parse(txtTSM.Text);
            int totalShotsAttempted = int.Parse(txtTSA.Text);
            int totalFreeThrowsAttempted = int.Parse(txtTFTA.Text);
            int freeThrowsMade = int.Parse(txtFTM.Text);
            double shootingPercentage = double.Parse(txtSP.Text);
            double freeThrowPercentage = double.Parse(txtFTP.Text);
            string imageURL = txtImgUrl.Text;
            playerManager.UpdatePlayer(id, name, age, position, gamesPlayed, pointsPerGame, assistsPerGame, reboundsPerGame, stealsPerGame, totalShotsMade, totalShotsAttempted, totalFreeThrowsAttempted, freeThrowsMade, shootingPercentage, freeThrowPercentage, imageURL);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
