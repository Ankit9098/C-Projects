﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyClassLibrary;

namespace SportsTeamManagement
{
    public partial class frmGameScore : Form
    {
        private frmSchedule ownerForm;
        gameSchedule createSchedule = new gameSchedule();
        GameScheduleManager manageSchedule = new GameScheduleManager();
        public frmGameScore()
        {
            InitializeComponent();
        }
        public void SetOwner(Form theForm)
        {
            // Cast the form to the correct class.
            ownerForm = (frmSchedule)theForm;
        }

        

        private void frmGameScore_Load(object sender, EventArgs e)
        {
            dgvViewGames.DataSource = manageSchedule.GetGames();

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            int ID = int.Parse(txtVenueID.Text);
            DateTime gameDate = DateTime.Parse(txtGameDate.Text);
            string homeTeam = txtHomeTeam.Text;
            string awayTeam = txtAwayTeam.Text;
            double homeScore = double.Parse(txtHomeScore.Text);
            double awayScore = double.Parse(txtAwayScore.Text);
            createSchedule = new gameSchedule(ID, gameDate, homeTeam, awayTeam, homeScore, awayScore);
            manageSchedule.UpdateVenue(createSchedule);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
