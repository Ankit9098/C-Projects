﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace SportsTeamManagement
{
    public partial class frmDashboard : Form
    {
        public frmDashboard()
        {
            InitializeComponent();
        }

        private void frmDashboard_Load(object sender, EventArgs e)
        {
            // Create a new Panel
            Panel panel1 = new Panel
            {
                Size = new Size(200, 100), // Set the size of the panel
                BorderStyle = BorderStyle.FixedSingle // Set border style for visibility
            };

            Panel panel2 = new Panel
            {
                Size = new Size(200, 100), // Set the size of the panel
                BorderStyle = BorderStyle.FixedSingle // Set border style for visibility
            };

            Panel panel3 = new Panel
            {
                Size = new Size(200, 100), // Set the size of the panel
                BorderStyle = BorderStyle.FixedSingle // Set border style for visibility
            };
            Panel panel4 = new Panel
            {
                Size = new Size(200, 100), // Set the size of the panel
                BorderStyle = BorderStyle.FixedSingle // Set border style for visibility
            };
            Panel panel5 = new Panel
            {
                Size = new Size(200, 100), // Set the size of the panel
                BorderStyle = BorderStyle.FixedSingle // Set border style for visibility
            };


            // Create a new button
            Button btnOpenPlayerManagement = new Button
            {
                Text = "Manage Players",
                Size = new Size(150, 30), // Set size as needed
                Location = new Point(25, 35) // Set location relative to the panel
            };

            Button btnOpenCreateTeams = new Button
            {
                Text = "Manage Teams",
                Size = new Size(150, 30), // Set size as needed
                Location = new Point(25, 35) // Set location relative to the panel
            };

            Button btnAddPlayerOnTeam = new Button
            {
                Text = "Add Players On Teams",
                Size = new Size(150, 30), // Set size as needed
                Location = new Point(25, 35) // Set location relative to the panel
            };

            Button btnGameSchedule = new Button
            {
                Text = "Create Game Schedule",
                Size = new Size(150, 30), // Set size as needed
                Location = new Point(25, 35) // Set location relative to the panel
            };

            Button btnViewCharts = new Button
            {
                Text = "View Charts",
                Size = new Size(150, 30), // Set size as needed
                Location = new Point(25, 35) // Set location relative to the panel
            };

            // Wire up the click event
            btnOpenPlayerManagement.Click += new EventHandler(btnOpenPlayerManagement_Click);
            btnOpenCreateTeams.Click += new EventHandler(btnOpenCreateTeams_Click);
            btnAddPlayerOnTeam.Click += new EventHandler(btnAddPlayerOnTeam_Click);
            btnGameSchedule.Click += new EventHandler(btnGameSchedule_Click);
            btnViewCharts.Click += new EventHandler(btnViewCharts_Click);

            // Add the button to the panel
            panel1.Controls.Add(btnOpenPlayerManagement);
            panel2.Controls.Add(btnOpenCreateTeams);
            panel3.Controls.Add(btnAddPlayerOnTeam);
            panel4.Controls.Add(btnGameSchedule);
            panel5.Controls.Add(btnViewCharts);


            // Add the panel to the FlowLayoutPanel instead of directly to the form's controls
            flpDashboard.Controls.Add(panel1);
            flpDashboard.Controls.Add(panel2);
            flpDashboard.Controls.Add(panel3);
            flpDashboard.Controls.Add(panel4);
            flpDashboard.Controls.Add(panel5);

        }


        private void btnOpenPlayerManagement_Click(object sender, EventArgs e)
        {
            frmPlayerManagement playerManagementForm = new frmPlayerManagement();
            playerManagementForm.ShowDialog();
        }

        private void btnOpenCreateTeams_Click(object sender, EventArgs e)
        {
            frmCreateTeam createTeam = new frmCreateTeam();
            createTeam.ShowDialog();
        }

        private void btnAddPlayerOnTeam_Click(object sender, EventArgs e)
        {
            frmManageTeam manageTeams = new frmManageTeam();
            manageTeams.ShowDialog();
        }

        private void btnGameSchedule_Click(object sender, EventArgs e)
        {
            frmSchedule scheudle = new frmSchedule();
            scheudle.ShowDialog();
        }

        private void flpDashboard_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnViewCharts_Click(object sender, EventArgs e)
        {
            frmCharts charts = new frmCharts();
            charts.ShowDialog();
        }
    }
}