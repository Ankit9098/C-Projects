﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyClassLibrary;

namespace SportsTeamManagement
{
    public partial class frmLogin : Form
    {
        Users user = new Users();
        UserManager userManager = new UserManager();
        RoleManager roleManager = new RoleManager();
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            string userName = txtUsername.Text;
            string password = txtPassword.Text;
            bool isValid = roleManager.FindIfCredentialsValid(userName, password);
            if (isValid == true)
            {
                MessageBox.Show("Authenicated");
            }
            else
            {
                MessageBox.Show("Username or Password was incorrect");
                return;
            }

            bool isCoach = roleManager.FindIfCoach(userName);
            bool isManager = roleManager.FindIfManager(userName);
            if (isCoach == true)
            {
                MessageBox.Show("Welcome Coach");
                frmDashboard dashboard = new frmDashboard();
                dashboard.ShowDialog();
            }

            if (isManager == true)
            {
                MessageBox.Show("Welcome Manager");
                frmDashboard dashboard  = new frmDashboard();
                dashboard.ShowDialog();
            }
            //frmDashboard dashboard = new frmDashboard();
            //dashboard.ShowDialog();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            frmSignUp signUp = new frmSignUp();
            signUp.ShowDialog();
        }

        private void CheckStringTextValues(object sender, CancelEventArgs e)
        {

        }

        private void CheckPasswordValues(object sender, CancelEventArgs e)
        {

        }
    }
}
