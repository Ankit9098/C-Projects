﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyClassLibrary;

namespace SportsTeamManagement
{
    public partial class frmCreateTeam : Form
    {
        Team team;
        TeamManager teamManager;
        public frmCreateTeam()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string logoUrl = txtLogoUrl.Text;
                picLogo.Load(logoUrl);

                int id = int.Parse(txtTeamID.Text);
                string name = txtTeamName.Text;
                string homeCity = txtHomeCity.Text;

                Team team = new Team(id, name, homeCity, logoUrl);

                TeamManager teamManager = new TeamManager();
                teamManager.AddTeamInDatabase(team);

                MessageBox.Show("Team added successfully with the logo.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load logo from the URL" + ex.Message);
            }
        }

        private void frmCreateTeam_Load(object sender, EventArgs e)
        {

        }

        private void CheckStringTextValues(object sender, CancelEventArgs e)
        {
            double value = 0;
            TextBox control = (TextBox)sender;
            if (string.IsNullOrEmpty(control.Text))
            {
                MessageBox.Show("The " + control.Name + " cannot be blank");
                e.Cancel = true;
            }
            else if (double.TryParse(control.Text, out value))
            {
                MessageBox.Show("The " + control.Name + "must be letters");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }

        private void CheckNullValues(object sender, CancelEventArgs e)
        {
            double value = 0;
            TextBox control = (TextBox)sender;
            if (string.IsNullOrEmpty(control.Text))
            {
                MessageBox.Show("The " + control.Name + " cannot be blank");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }

        private void CheckIntTextValues(object sender, CancelEventArgs e)
        {
            int value = 0;
            TextBox control = (TextBox)sender;

            if (string.IsNullOrEmpty(control.Text))
            {
                MessageBox.Show("The " + control.Name + " cannot be blank");
                e.Cancel = true;
            }
            else if (!int.TryParse(control.Text, out value))
            {
                MessageBox.Show("The " + control.Name + "must be numerical numbers");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }

        private void CheckUrlTextValues(object sender, CancelEventArgs e)
        {
            TextBox control = (TextBox)sender;
            if (string.IsNullOrEmpty(control.Text))
            {
                MessageBox.Show("The URL for " + control.Name + " cannot be blank.");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
