﻿namespace SportsTeamManagement
{
    partial class frmGameScore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtVenueID = new System.Windows.Forms.TextBox();
            this.txtGameDate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtHomeTeam = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAwayTeam = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtHomeScore = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAwayScore = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvViewGames = new System.Windows.Forms.DataGridView();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewGames)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please Enter a VenueID to chnage the score for:";
            // 
            // txtVenueID
            // 
            this.txtVenueID.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtVenueID.Location = new System.Drawing.Point(16, 30);
            this.txtVenueID.Name = "txtVenueID";
            this.txtVenueID.Size = new System.Drawing.Size(100, 20);
            this.txtVenueID.TabIndex = 1;
            // 
            // txtGameDate
            // 
            this.txtGameDate.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtGameDate.Location = new System.Drawing.Point(16, 88);
            this.txtGameDate.Name = "txtGameDate";
            this.txtGameDate.Size = new System.Drawing.Size(100, 20);
            this.txtGameDate.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Game Date";
            // 
            // txtHomeTeam
            // 
            this.txtHomeTeam.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtHomeTeam.Location = new System.Drawing.Point(16, 147);
            this.txtHomeTeam.Name = "txtHomeTeam";
            this.txtHomeTeam.Size = new System.Drawing.Size(100, 20);
            this.txtHomeTeam.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Home Team";
            // 
            // txtAwayTeam
            // 
            this.txtAwayTeam.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtAwayTeam.Location = new System.Drawing.Point(16, 210);
            this.txtAwayTeam.Name = "txtAwayTeam";
            this.txtAwayTeam.Size = new System.Drawing.Size(100, 20);
            this.txtAwayTeam.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Away Team";
            // 
            // txtHomeScore
            // 
            this.txtHomeScore.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtHomeScore.Location = new System.Drawing.Point(16, 272);
            this.txtHomeScore.Name = "txtHomeScore";
            this.txtHomeScore.Size = new System.Drawing.Size(100, 20);
            this.txtHomeScore.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 255);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Home Score";
            // 
            // txtAwayScore
            // 
            this.txtAwayScore.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtAwayScore.Location = new System.Drawing.Point(16, 337);
            this.txtAwayScore.Name = "txtAwayScore";
            this.txtAwayScore.Size = new System.Drawing.Size(100, 20);
            this.txtAwayScore.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 320);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Away Score";
            // 
            // dgvViewGames
            // 
            this.dgvViewGames.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dgvViewGames.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvViewGames.Location = new System.Drawing.Point(209, 30);
            this.dgvViewGames.Name = "dgvViewGames";
            this.dgvViewGames.Size = new System.Drawing.Size(579, 238);
            this.dgvViewGames.TabIndex = 12;
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnSubmit.Location = new System.Drawing.Point(209, 302);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(124, 31);
            this.btnSubmit.TabIndex = 13;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnBack.Location = new System.Drawing.Point(349, 302);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(124, 31);
            this.btnBack.TabIndex = 14;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmGameScore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.dgvViewGames);
            this.Controls.Add(this.txtAwayScore);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtHomeScore);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtAwayTeam);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtHomeTeam);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtGameDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtVenueID);
            this.Controls.Add(this.label1);
            this.Name = "frmGameScore";
            this.Text = "frmGameScore";
            this.Load += new System.EventHandler(this.frmGameScore_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewGames)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txtVenueID;
        public System.Windows.Forms.TextBox txtGameDate;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox txtHomeTeam;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox txtAwayTeam;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox txtHomeScore;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox txtAwayScore;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.DataGridView dgvViewGames;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnBack;
    }
}