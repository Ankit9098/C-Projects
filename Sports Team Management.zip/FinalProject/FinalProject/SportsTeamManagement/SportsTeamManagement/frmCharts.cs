﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using MyClassLibrary;

namespace SportsTeamManagement
{
    
    public partial class frmCharts : Form
    {
        private Players createPlayers = new Players();
        private PlayerManager managePlayers = new PlayerManager();
        public frmCharts()
        {
            InitializeComponent();
        }

        private void frmCharts_Load(object sender, EventArgs e)
        {
            cmbCategories.DataSource = Enum.GetValues(typeof(Players.Categories));
            dgvAllPlayers.DataSource = managePlayers.GetAllPlayers();
        }

        private void UpdateChart()
        {
            string category = cmbCategories.SelectedItem.ToString();
            int topValue;

            if (int.TryParse(txtCount.Text, out topValue))
            {
                List<Players> topPlayers = managePlayers.GetTopPlayersInCategory(category, topValue);

                // Clear the chart
                chrtViewDisplay.Series.Clear();

                // Create a new series for Top Players
                Series series = new Series();
                series.Name = "Top Players";
                series.ChartType = SeriesChartType.Column;

                // Add points into the series
                foreach (Players player in topPlayers)
                {
                    double value = GetCategoryValue(player, category);
                    series.Points.AddXY(player.Name, value);
                }

                // Finally Add the series to the chart
                chrtViewDisplay.Series.Add(series);

                // Modify the title and labels for the chart
                chrtViewDisplay.Titles.Clear();
                chrtViewDisplay.Titles.Add("Top Players by " + category);
                chrtViewDisplay.ChartAreas[0].AxisX.Title = "Player";
                chrtViewDisplay.ChartAreas[0].AxisY.Title = category;
            }
        }

        private double GetCategoryValue(Players player, string category)
        {
            if (category == "PlayerPPG")
            {
                return player.PointsPerGame;
            }
            else if (category == "PlayerAPG")
            {
                return player.AssistsPerGame;
            }
            else if (category == "PlayerRPG")
            {
                return player.ReboundsPerGame;
            }
            else
            {
                return 0;
            }
        }

        private void cmbCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateChart();
        }

        private void txtCount_TextChanged(object sender, EventArgs e)
        {
            UpdateChart();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int playerID = int.Parse(dgvAllPlayers.SelectedRows[0].Cells[0].Value.ToString());
            double APGStats = managePlayers.FindAllAPGCarerrStas(playerID);
            double RPGStats = managePlayers.FindAllRPGCarerrStas(playerID);
            double PPGStats = managePlayers.FindAllPPGCarerrStas(playerID);
            lblStats.Text = "The players Carrers Points are " + PPGStats +
                            ", the players Carrer Rebounds are " + RPGStats + ", the player Carrer Assists are " +
                            APGStats;

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
