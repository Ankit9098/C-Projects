﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyClassLibrary;

namespace SportsTeamManagement
{
    public partial class frmManageTeam : Form
    {
        private PlayerManager managePlayer = new PlayerManager();
         TeamManager managerTeam = new TeamManager();
        public frmManageTeam()
        {
            InitializeComponent();
        }

        private void frmManageTeam_Load(object sender, EventArgs e)
        {
            List<String> teamNames = managerTeam.ViewAllTeamsInDatabase();
            cmbTeam.DataSource = teamNames;
            cmbPositions.DataSource = Enum.GetValues(typeof(Players.BasketballPosition));
            List<Players> allPlayersList = new List<Players>();
            allPlayersList = managePlayer.ViewPlayerDatabase();
            dgvViewSearchedPlayers.AutoGenerateColumns = false;
            dgvViewSearchedPlayers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvViewSearchedPlayers.DataSource = allPlayersList;
            dgvPlayersInTeam.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string position = cmbPositions.SelectedItem.ToString();
            List<Players> allPlayersList = new List<Players>();
            allPlayersList = managePlayer.ViewPlayerDatabase();
            List<Players> filteredPlayers = new List<Players>();
            filteredPlayers = managePlayer.FilterByPosition(allPlayersList, position);
            dgvViewSearchedPlayers.DataSource = filteredPlayers;

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string teamName  = cmbTeam.SelectedItem.ToString();
            int teamID = managerTeam.GetTeamID(teamName);
            int playerID = int.Parse(dgvViewSearchedPlayers.SelectedRows[0].Cells[0].Value.ToString());
            managerTeam.AddPlayerInTeam(teamID, playerID);
        }

        private void cmbTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            string teamName = cmbTeam.SelectedItem.ToString();
            int teamID = managerTeam.GetTeamID(teamName);
            string logoURL = managerTeam.FindTeamLogo(teamID);
            pcbxLogo.Load(logoURL);
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string teamName = cmbTeam.SelectedItem.ToString();
            int teamID = managerTeam.GetTeamID(teamName);
            MessageBox.Show(teamName);
            List<Players> filteredPlayersInTeam = new List<Players>();
            filteredPlayersInTeam = managerTeam.GetPlayersForTeam(teamID);
            dgvPlayersInTeam.DataSource = filteredPlayersInTeam;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int playerID = int.Parse(dgvPlayersInTeam.SelectedRows[0].Cells[0].Value.ToString());
            managerTeam.DeletePlayersFromTeam(playerID);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
