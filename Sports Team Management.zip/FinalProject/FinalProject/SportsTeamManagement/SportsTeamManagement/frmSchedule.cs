﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyClassLibrary;

namespace SportsTeamManagement
{
    public partial class frmSchedule : Form
    {
         gameSchedule game = new gameSchedule();
         GameScheduleManager scheduleManage = new GameScheduleManager();

         private PlayerManager managePlayer = new PlayerManager();
         TeamManager managerTeam = new TeamManager();
        public frmSchedule()
        {
            InitializeComponent();
            List<String> teamNames = managerTeam.ViewAllTeamsInDatabase();
            List<String> awayTeams = managerTeam.ViewAllTeamsInDatabase();
            List<String> homeTeams = managerTeam.ViewAllTeamsInDatabase();
            cmbHome.DataSource = homeTeams;
            cmbAway.DataSource = awayTeams;
        }

        private void btnSchedule_Click(object sender, EventArgs e)
        {
            DateTime dtpGameDate = dtpSchedule.Value;
            int venueID = int.Parse(txtVenueID.Text);
            string homeTeam = cmbHome.SelectedItem.ToString();
            string awayTeam = cmbAway.SelectedItem.ToString();
            game = new gameSchedule(venueID, dtpGameDate, homeTeam, awayTeam);
            scheduleManage.AddVenue(game);
        }

        private void frmSchedule_Load(object sender, EventArgs e)
        {
            List<String> awayTeams = managerTeam.ViewAllTeamsInDatabase();
            List<String> homeTeams = managerTeam.ViewAllTeamsInDatabase();
            cmbHome.DataSource = homeTeams;
            cmbAway.DataSource = awayTeams;

        }

        private void cmbAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            string awayTeamName = cmbAway.SelectedItem.ToString();
            int awayTeamID = managerTeam.GetTeamID(awayTeamName);
            string awayLogoURL = managerTeam.FindTeamLogo(awayTeamID);
            pcbxAwayTeam.Load(awayLogoURL);
        }

        private void cmbHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            string HometeamName = cmbHome.SelectedItem.ToString();
            int HometeamID = managerTeam.GetTeamID(HometeamName);
            string HomelogoURL = managerTeam.FindTeamLogo(HometeamID);
            pcbxHomeTeam.Load(HomelogoURL);
        }

        private void btnAddScore_Click(object sender, EventArgs e)
        {
            int venueID = int.Parse(txtVenueID.Text);
            DateTime dtpGameDate = dtpSchedule.Value;
            string homeTeam = cmbHome.SelectedItem.ToString();
            string awayTeam = cmbAway.SelectedItem.ToString();
            frmGameScore updateScore = new frmGameScore();
            updateScore.SetOwner(this);
            updateScore.txtVenueID.Text = venueID.ToString();
            updateScore.txtGameDate.Text = dtpGameDate.ToString();
            updateScore.txtHomeTeam.Text = homeTeam;
            updateScore.txtAwayTeam.Text = awayTeam;
            updateScore.ShowDialog();

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
