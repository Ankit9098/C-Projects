﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyClassLibrary;

namespace SportsTeamManagement
{
    public partial class frmPlayerManagement : Form
    {
        Players players = new Players();
        PlayerManager playerManager = new PlayerManager();
        public frmPlayerManagement()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
     
            int playerId = int.Parse(txtPlayerID.Text);
            string name = txtName.Text;
            int age = int.Parse(txtAge.Text);
            string position = cmbPosition.SelectedItem.ToString();
            int gamesPlayed = int.Parse(txtGamesPlayed.Text);
            MessageBox.Show($"{position}");
            double pointsPerGame = double.Parse(txtPPG.Text);
            double assistsPerGame = double.Parse(txtAPG.Text);
            double reboundsPerGame = double.Parse(txtRPG.Text);
            double stealsPerGame = double.Parse(txtSPG.Text);
            int totalShotsMade = int.Parse(txtTSM.Text);
            int totalShotsAttempted = int.Parse(txtTSA.Text);
            int totalFreeThrowsAttempted = int.Parse(txtTFTA.Text);
            int freeThrowsMade = int.Parse(txtFreeThrowsMade.Text);
            double shootingPercentage = 0;
            double freeThrowPercentage = 0;
            string playerImage = txtPlayerImage.Text;
            
            //int playerId, string name, int age, string position,
            //double pointsPerGame, double assistsPerGame, double reboundsPerGame, double stealsPerGame,
            //int totalShotsAttempted, int totalFreeThrowsAttempted, int freeThrowsMade, string imageURL

            players = new Players(playerId, name, age, position, gamesPlayed, pointsPerGame, assistsPerGame, reboundsPerGame, stealsPerGame, totalShotsMade,
                totalShotsAttempted, totalFreeThrowsAttempted, freeThrowsMade, playerImage);
            playerManager.AddPlayer(players);

        }

        private void frmPlayerManagement_Load(object sender, EventArgs e)
        {
            dgvViewAllPlayers.AutoGenerateColumns = false;
            dgvViewAllPlayers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            cmbPosition.DataSource = Enum.GetValues(typeof(Players.BasketballPosition));
            dgvViewAllPlayers.DataSource = playerManager.ViewPlayerDatabase();
            

            //dgvViewAllPlayers.DataSource = playerManager.ViewPlayerDatabase();
        }

        private void txtPlayerID_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int playerID = int.Parse(dgvViewAllPlayers.SelectedRows[0].Cells[0].Value.ToString());
            frmUpdatePlayer updatePlayer = new frmUpdatePlayer();
            updatePlayer.SetOwner(this);
            List<Players> playerSearched = playerManager.SearchPlayersDatabaseByPlayerID(playerID);
            foreach (Players player in playerSearched)
            {
                try
                {
                    updatePlayer.txtPlayerID.Text = player.PlayerId.ToString();
                    updatePlayer.txtName.Text = player.Name;
                    updatePlayer.txtAge.Text = player.Age.ToString();
                    updatePlayer.cmbPosition.SelectedItem = player.Position.ToString();
                    updatePlayer.txtGamesPlayed.Text = player.GamesPlayed.ToString();
                    updatePlayer.txtPPG.Text = player.PointsPerGame.ToString();
                    updatePlayer.txtAPG.Text = player.AssistsPerGame.ToString();
                    updatePlayer.txtRPG.Text = player.ReboundsPerGame.ToString();
                    updatePlayer.txtSPG.Text = player.StealsPerGame.ToString();
                    updatePlayer.txtTSM.Text = player.TotalShotsMade.ToString();
                    updatePlayer.txtTSA.Text = player.TotalShotsAttempted.ToString();
                    updatePlayer.txtTFTA.Text = player.TotalFreeThrowsAttempted.ToString();
                    updatePlayer.txtFTM.Text = player.FreeThrowsMade.ToString();
                    updatePlayer.txtSP.Text = player.ShootingPercentage.ToString();
                    updatePlayer.txtFTP.Text = player.FreeThrowPercentage.ToString();
                    updatePlayer.txtImgUrl.Text = player.ImageUrl;
                    updatePlayer.pcbxPlayerImg.Load(player.ImageUrl);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    throw;
                }
            }

            updatePlayer.ShowDialog();
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int playerID = int.Parse(dgvViewAllPlayers.SelectedRows[0].Cells[0].Value.ToString());
            playerManager.DeletePlayer(playerID);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
