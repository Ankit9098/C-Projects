﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyClassLibrary;

namespace SportsTeamManagement
{
    public partial class frmSignUp : Form
    {
        private Users user = new Users();
        private UserManager userManager = new UserManager();
        public frmSignUp()
        {
            InitializeComponent();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            user = new Users(txtUserName.Text, txtPassword.Text, txtFirstName.Text, txtLastName.Text,
                cmbAccessLevel.SelectedItem.ToString());
            bool findIfUserAdded = userManager.AddUserIntoDatabase(user);
            if (findIfUserAdded == true)
            {
                MessageBox.Show("The user was successfully added");
            }
            else
            {
                MessageBox.Show("Please try again");
            }

        }

        private void frmSignUp_Load(object sender, EventArgs e)
        {
            //  This method retrieves an array of the values in the AccessLevel and sets the data source of the ComboBox to the array of those enum values.
            cmbAccessLevel.DataSource = Enum.GetValues(typeof(Users.AccessLevel));

        }

        private void CheckStringTextValues(object sender, CancelEventArgs e)
        {
            double value = 0;
            TextBox control = (TextBox)sender;
            if (string.IsNullOrEmpty(control.Text))
            {
                MessageBox.Show("The " + control.Name + " cannot be blank");
                e.Cancel = true;
            }
            else if (double.TryParse(control.Text, out value))
            {
                MessageBox.Show("The " + control.Name + "must be letters");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }

        private void CheckNullValues(object sender, CancelEventArgs e)
        {
            double value = 0;
            TextBox control = (TextBox)sender;
            if (string.IsNullOrEmpty(control.Text))
            {
                MessageBox.Show("The " + control.Name + " cannot be blank");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }

        private void CheckIfPasswordMatch(object sender, CancelEventArgs e)
        {
            TextBox control = (TextBox)sender;
            if (string.IsNullOrEmpty(control.Text))
            {
                MessageBox.Show("The " + control.Name + " cannot be blank");
                e.Cancel = true;
            }
            else if (txtPassword.Text != control.Text)
            {
                MessageBox.Show("The " + control.Name + "Password don't match");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }
    }
}
