﻿namespace SportsTeamManagement
{
    partial class frmCreateTeam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtTeamID = new System.Windows.Forms.TextBox();
            this.txtTeamName = new System.Windows.Forms.TextBox();
            this.lblTeamName = new System.Windows.Forms.Label();
            this.txtHomeCity = new System.Windows.Forms.TextBox();
            this.lblHomeCity = new System.Windows.Forms.Label();
            this.txtLogoUrl = new System.Windows.Forms.TextBox();
            this.lblTeamLogo = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Team ID:";
            // 
            // txtTeamID
            // 
            this.txtTeamID.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtTeamID.Location = new System.Drawing.Point(16, 39);
            this.txtTeamID.Name = "txtTeamID";
            this.txtTeamID.Size = new System.Drawing.Size(100, 20);
            this.txtTeamID.TabIndex = 1;
            this.txtTeamID.Validating += new System.ComponentModel.CancelEventHandler(this.CheckIntTextValues);
            // 
            // txtTeamName
            // 
            this.txtTeamName.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtTeamName.Location = new System.Drawing.Point(16, 98);
            this.txtTeamName.Name = "txtTeamName";
            this.txtTeamName.Size = new System.Drawing.Size(100, 20);
            this.txtTeamName.TabIndex = 3;
            this.txtTeamName.Validating += new System.ComponentModel.CancelEventHandler(this.CheckStringTextValues);
            // 
            // lblTeamName
            // 
            this.lblTeamName.AutoSize = true;
            this.lblTeamName.Location = new System.Drawing.Point(13, 81);
            this.lblTeamName.Name = "lblTeamName";
            this.lblTeamName.Size = new System.Drawing.Size(68, 13);
            this.lblTeamName.TabIndex = 2;
            this.lblTeamName.Text = "Team Name:";
            // 
            // txtHomeCity
            // 
            this.txtHomeCity.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtHomeCity.Location = new System.Drawing.Point(16, 167);
            this.txtHomeCity.Name = "txtHomeCity";
            this.txtHomeCity.Size = new System.Drawing.Size(100, 20);
            this.txtHomeCity.TabIndex = 5;
            this.txtHomeCity.Validating += new System.ComponentModel.CancelEventHandler(this.CheckStringTextValues);
            // 
            // lblHomeCity
            // 
            this.lblHomeCity.AutoSize = true;
            this.lblHomeCity.Location = new System.Drawing.Point(13, 150);
            this.lblHomeCity.Name = "lblHomeCity";
            this.lblHomeCity.Size = new System.Drawing.Size(58, 13);
            this.lblHomeCity.TabIndex = 4;
            this.lblHomeCity.Text = "Home City:";
            // 
            // txtLogoUrl
            // 
            this.txtLogoUrl.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtLogoUrl.Location = new System.Drawing.Point(16, 239);
            this.txtLogoUrl.Name = "txtLogoUrl";
            this.txtLogoUrl.Size = new System.Drawing.Size(100, 20);
            this.txtLogoUrl.TabIndex = 7;
            this.txtLogoUrl.Validating += new System.ComponentModel.CancelEventHandler(this.CheckUrlTextValues);
            // 
            // lblTeamLogo
            // 
            this.lblTeamLogo.AutoSize = true;
            this.lblTeamLogo.Location = new System.Drawing.Point(13, 222);
            this.lblTeamLogo.Name = "lblTeamLogo";
            this.lblTeamLogo.Size = new System.Drawing.Size(61, 13);
            this.lblTeamLogo.TabIndex = 6;
            this.lblTeamLogo.Text = "Team Logo";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnAdd.Location = new System.Drawing.Point(16, 287);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 8;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // picLogo
            // 
            this.picLogo.Location = new System.Drawing.Point(213, 81);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(153, 191);
            this.picLogo.TabIndex = 9;
            this.picLogo.TabStop = false;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnBack.Location = new System.Drawing.Point(16, 336);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 10;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // frmCreateTeam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(563, 543);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtLogoUrl);
            this.Controls.Add(this.lblTeamLogo);
            this.Controls.Add(this.txtHomeCity);
            this.Controls.Add(this.lblHomeCity);
            this.Controls.Add(this.txtTeamName);
            this.Controls.Add(this.lblTeamName);
            this.Controls.Add(this.txtTeamID);
            this.Controls.Add(this.label1);
            this.Name = "frmCreateTeam";
            this.Text = "frmCreate";
            this.Load += new System.EventHandler(this.frmCreateTeam_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTeamID;
        private System.Windows.Forms.TextBox txtTeamName;
        private System.Windows.Forms.Label lblTeamName;
        private System.Windows.Forms.TextBox txtHomeCity;
        private System.Windows.Forms.Label lblHomeCity;
        private System.Windows.Forms.TextBox txtLogoUrl;
        private System.Windows.Forms.Label lblTeamLogo;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Button btnBack;
    }
}