﻿namespace SportsTeamManagement
{
    partial class frmSchedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtpSchedule = new System.Windows.Forms.DateTimePicker();
            this.lblAway = new System.Windows.Forms.Label();
            this.lblHome = new System.Windows.Forms.Label();
            this.lblVS = new System.Windows.Forms.Label();
            this.pcbxAwayTeam = new System.Windows.Forms.PictureBox();
            this.pcbxHomeTeam = new System.Windows.Forms.PictureBox();
            this.btnSchedule = new System.Windows.Forms.Button();
            this.txtVenueID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbAway = new System.Windows.Forms.ComboBox();
            this.cmbHome = new System.Windows.Forms.ComboBox();
            this.btnAddScore = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblPlease = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxAwayTeam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxHomeTeam)).BeginInit();
            this.SuspendLayout();
            // 
            // dtpSchedule
            // 
            this.dtpSchedule.CalendarMonthBackground = System.Drawing.SystemColors.ControlLight;
            this.dtpSchedule.Location = new System.Drawing.Point(279, 109);
            this.dtpSchedule.Name = "dtpSchedule";
            this.dtpSchedule.Size = new System.Drawing.Size(200, 20);
            this.dtpSchedule.TabIndex = 0;
            // 
            // lblAway
            // 
            this.lblAway.AutoSize = true;
            this.lblAway.Location = new System.Drawing.Point(131, 116);
            this.lblAway.Name = "lblAway";
            this.lblAway.Size = new System.Drawing.Size(63, 13);
            this.lblAway.TabIndex = 1;
            this.lblAway.Text = "Away Team";
            // 
            // lblHome
            // 
            this.lblHome.AutoSize = true;
            this.lblHome.Location = new System.Drawing.Point(546, 116);
            this.lblHome.Name = "lblHome";
            this.lblHome.Size = new System.Drawing.Size(65, 13);
            this.lblHome.TabIndex = 2;
            this.lblHome.Text = "Home Team";
            // 
            // lblVS
            // 
            this.lblVS.AutoSize = true;
            this.lblVS.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVS.Location = new System.Drawing.Point(334, 192);
            this.lblVS.Name = "lblVS";
            this.lblVS.Size = new System.Drawing.Size(52, 31);
            this.lblVS.TabIndex = 5;
            this.lblVS.Text = "VS";
            // 
            // pcbxAwayTeam
            // 
            this.pcbxAwayTeam.Location = new System.Drawing.Point(101, 144);
            this.pcbxAwayTeam.Name = "pcbxAwayTeam";
            this.pcbxAwayTeam.Size = new System.Drawing.Size(121, 129);
            this.pcbxAwayTeam.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbxAwayTeam.TabIndex = 6;
            this.pcbxAwayTeam.TabStop = false;
            // 
            // pcbxHomeTeam
            // 
            this.pcbxHomeTeam.Location = new System.Drawing.Point(515, 144);
            this.pcbxHomeTeam.Name = "pcbxHomeTeam";
            this.pcbxHomeTeam.Size = new System.Drawing.Size(121, 129);
            this.pcbxHomeTeam.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbxHomeTeam.TabIndex = 7;
            this.pcbxHomeTeam.TabStop = false;
            // 
            // btnSchedule
            // 
            this.btnSchedule.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnSchedule.Location = new System.Drawing.Point(279, 262);
            this.btnSchedule.Name = "btnSchedule";
            this.btnSchedule.Size = new System.Drawing.Size(75, 23);
            this.btnSchedule.TabIndex = 8;
            this.btnSchedule.Text = "Schedule";
            this.btnSchedule.UseVisualStyleBackColor = false;
            this.btnSchedule.Click += new System.EventHandler(this.btnSchedule_Click);
            // 
            // txtVenueID
            // 
            this.txtVenueID.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtVenueID.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVenueID.Location = new System.Drawing.Point(200, 22);
            this.txtVenueID.Name = "txtVenueID";
            this.txtVenueID.Size = new System.Drawing.Size(107, 22);
            this.txtVenueID.TabIndex = 10;
            this.txtVenueID.Text = "1910";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 46);
            this.label1.TabIndex = 9;
            this.label1.Text = "Venue ID:";
            // 
            // cmbAway
            // 
            this.cmbAway.BackColor = System.Drawing.SystemColors.ControlLight;
            this.cmbAway.FormattingEnabled = true;
            this.cmbAway.Location = new System.Drawing.Point(101, 296);
            this.cmbAway.Name = "cmbAway";
            this.cmbAway.Size = new System.Drawing.Size(121, 21);
            this.cmbAway.TabIndex = 11;
            this.cmbAway.SelectedIndexChanged += new System.EventHandler(this.cmbAway_SelectedIndexChanged);
            // 
            // cmbHome
            // 
            this.cmbHome.BackColor = System.Drawing.SystemColors.ControlLight;
            this.cmbHome.FormattingEnabled = true;
            this.cmbHome.Location = new System.Drawing.Point(515, 295);
            this.cmbHome.Name = "cmbHome";
            this.cmbHome.Size = new System.Drawing.Size(121, 21);
            this.cmbHome.TabIndex = 12;
            this.cmbHome.SelectedIndexChanged += new System.EventHandler(this.cmbHome_SelectedIndexChanged);
            // 
            // btnAddScore
            // 
            this.btnAddScore.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnAddScore.Location = new System.Drawing.Point(368, 262);
            this.btnAddScore.Name = "btnAddScore";
            this.btnAddScore.Size = new System.Drawing.Size(75, 23);
            this.btnAddScore.TabIndex = 13;
            this.btnAddScore.Text = "Add Score";
            this.btnAddScore.UseVisualStyleBackColor = false;
            this.btnAddScore.Click += new System.EventHandler(this.btnAddScore_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnBack.Location = new System.Drawing.Point(322, 307);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 14;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblPlease
            // 
            this.lblPlease.AutoSize = true;
            this.lblPlease.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlease.ForeColor = System.Drawing.Color.DarkRed;
            this.lblPlease.Location = new System.Drawing.Point(197, 47);
            this.lblPlease.Name = "lblPlease";
            this.lblPlease.Size = new System.Drawing.Size(122, 13);
            this.lblPlease.TabIndex = 15;
            this.lblPlease.Text = "*Please type a venue ID";
            // 
            // frmSchedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblPlease);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnAddScore);
            this.Controls.Add(this.cmbHome);
            this.Controls.Add(this.cmbAway);
            this.Controls.Add(this.txtVenueID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSchedule);
            this.Controls.Add(this.pcbxHomeTeam);
            this.Controls.Add(this.pcbxAwayTeam);
            this.Controls.Add(this.lblVS);
            this.Controls.Add(this.lblHome);
            this.Controls.Add(this.lblAway);
            this.Controls.Add(this.dtpSchedule);
            this.Name = "frmSchedule";
            this.Text = "frmSchedule";
            this.Load += new System.EventHandler(this.frmSchedule_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcbxAwayTeam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxHomeTeam)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpSchedule;
        private System.Windows.Forms.Label lblAway;
        private System.Windows.Forms.Label lblHome;
        private System.Windows.Forms.Label lblVS;
        private System.Windows.Forms.PictureBox pcbxAwayTeam;
        private System.Windows.Forms.PictureBox pcbxHomeTeam;
        private System.Windows.Forms.Button btnSchedule;
        public System.Windows.Forms.TextBox txtVenueID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbAway;
        private System.Windows.Forms.ComboBox cmbHome;
        private System.Windows.Forms.Button btnAddScore;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblPlease;
    }
}