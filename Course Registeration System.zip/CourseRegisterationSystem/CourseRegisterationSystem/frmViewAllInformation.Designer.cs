﻿namespace CourseRegisterationSystem
{
    partial class frmViewAllInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pcbxProfessorImage = new System.Windows.Forms.PictureBox();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.txtCrCode = new System.Windows.Forms.TextBox();
            this.rchtxtCrsDescription = new System.Windows.Forms.RichTextBox();
            this.txtCrsTitle = new System.Windows.Forms.TextBox();
            this.txtCrsCredits = new System.Windows.Forms.TextBox();
            this.txtCrsPreRequisites = new System.Windows.Forms.TextBox();
            this.txtFirstDay = new System.Windows.Forms.TextBox();
            this.txtSecondDay = new System.Windows.Forms.TextBox();
            this.txtThirdDay = new System.Windows.Forms.TextBox();
            this.txtMaxSeats = new System.Windows.Forms.TextBox();
            this.txtAvaliableSeats = new System.Windows.Forms.TextBox();
            this.txtProfessorName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxProfessorImage)).BeginInit();
            this.SuspendLayout();
            // 
            // pcbxProfessorImage
            // 
            this.pcbxProfessorImage.Location = new System.Drawing.Point(295, 288);
            this.pcbxProfessorImage.Name = "pcbxProfessorImage";
            this.pcbxProfessorImage.Size = new System.Drawing.Size(375, 515);
            this.pcbxProfessorImage.TabIndex = 1;
            this.pcbxProfessorImage.TabStop = false;
            // 
            // txtDepartment
            // 
            this.txtDepartment.Location = new System.Drawing.Point(12, 41);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.ReadOnly = true;
            this.txtDepartment.Size = new System.Drawing.Size(100, 20);
            this.txtDepartment.TabIndex = 2;
            // 
            // txtCrCode
            // 
            this.txtCrCode.Location = new System.Drawing.Point(12, 112);
            this.txtCrCode.Name = "txtCrCode";
            this.txtCrCode.ReadOnly = true;
            this.txtCrCode.Size = new System.Drawing.Size(100, 20);
            this.txtCrCode.TabIndex = 3;
            // 
            // rchtxtCrsDescription
            // 
            this.rchtxtCrsDescription.Location = new System.Drawing.Point(12, 291);
            this.rchtxtCrsDescription.Name = "rchtxtCrsDescription";
            this.rchtxtCrsDescription.ReadOnly = true;
            this.rchtxtCrsDescription.Size = new System.Drawing.Size(100, 96);
            this.rchtxtCrsDescription.TabIndex = 4;
            this.rchtxtCrsDescription.Text = "";
            // 
            // txtCrsTitle
            // 
            this.txtCrsTitle.Location = new System.Drawing.Point(12, 187);
            this.txtCrsTitle.Name = "txtCrsTitle";
            this.txtCrsTitle.ReadOnly = true;
            this.txtCrsTitle.Size = new System.Drawing.Size(100, 20);
            this.txtCrsTitle.TabIndex = 5;
            // 
            // txtCrsCredits
            // 
            this.txtCrsCredits.Location = new System.Drawing.Point(12, 459);
            this.txtCrsCredits.Name = "txtCrsCredits";
            this.txtCrsCredits.ReadOnly = true;
            this.txtCrsCredits.Size = new System.Drawing.Size(100, 20);
            this.txtCrsCredits.TabIndex = 6;
            // 
            // txtCrsPreRequisites
            // 
            this.txtCrsPreRequisites.Location = new System.Drawing.Point(12, 547);
            this.txtCrsPreRequisites.Name = "txtCrsPreRequisites";
            this.txtCrsPreRequisites.ReadOnly = true;
            this.txtCrsPreRequisites.Size = new System.Drawing.Size(100, 20);
            this.txtCrsPreRequisites.TabIndex = 7;
            // 
            // txtFirstDay
            // 
            this.txtFirstDay.Location = new System.Drawing.Point(12, 620);
            this.txtFirstDay.Name = "txtFirstDay";
            this.txtFirstDay.ReadOnly = true;
            this.txtFirstDay.Size = new System.Drawing.Size(100, 20);
            this.txtFirstDay.TabIndex = 8;
            // 
            // txtSecondDay
            // 
            this.txtSecondDay.Location = new System.Drawing.Point(12, 707);
            this.txtSecondDay.Name = "txtSecondDay";
            this.txtSecondDay.ReadOnly = true;
            this.txtSecondDay.Size = new System.Drawing.Size(100, 20);
            this.txtSecondDay.TabIndex = 9;
            // 
            // txtThirdDay
            // 
            this.txtThirdDay.Location = new System.Drawing.Point(12, 806);
            this.txtThirdDay.Name = "txtThirdDay";
            this.txtThirdDay.ReadOnly = true;
            this.txtThirdDay.Size = new System.Drawing.Size(100, 20);
            this.txtThirdDay.TabIndex = 10;
            // 
            // txtMaxSeats
            // 
            this.txtMaxSeats.Location = new System.Drawing.Point(295, 41);
            this.txtMaxSeats.Name = "txtMaxSeats";
            this.txtMaxSeats.ReadOnly = true;
            this.txtMaxSeats.Size = new System.Drawing.Size(100, 20);
            this.txtMaxSeats.TabIndex = 11;
            // 
            // txtAvaliableSeats
            // 
            this.txtAvaliableSeats.Location = new System.Drawing.Point(295, 112);
            this.txtAvaliableSeats.Name = "txtAvaliableSeats";
            this.txtAvaliableSeats.ReadOnly = true;
            this.txtAvaliableSeats.Size = new System.Drawing.Size(100, 20);
            this.txtAvaliableSeats.TabIndex = 12;
            // 
            // txtProfessorName
            // 
            this.txtProfessorName.Location = new System.Drawing.Point(295, 187);
            this.txtProfessorName.Name = "txtProfessorName";
            this.txtProfessorName.ReadOnly = true;
            this.txtProfessorName.Size = new System.Drawing.Size(100, 20);
            this.txtProfessorName.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Course Department";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Course Code";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Course Title";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 275);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Course Description";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 443);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Course Credits";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 531);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Course Pre-Requisites";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 604);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "First Day Class Held";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 691);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Second Day Class Held";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 790);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(106, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "Third Day Class Held";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(292, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(131, 13);
            this.label10.TabIndex = 23;
            this.label10.Text = "Maximum Number of setas";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(292, 96);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(80, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "Available Seats";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(292, 171);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "Professor Full Name";
            // 
            // frmViewAllInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(743, 873);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtProfessorName);
            this.Controls.Add(this.txtAvaliableSeats);
            this.Controls.Add(this.txtMaxSeats);
            this.Controls.Add(this.txtThirdDay);
            this.Controls.Add(this.txtSecondDay);
            this.Controls.Add(this.txtFirstDay);
            this.Controls.Add(this.txtCrsPreRequisites);
            this.Controls.Add(this.txtCrsCredits);
            this.Controls.Add(this.txtCrsTitle);
            this.Controls.Add(this.rchtxtCrsDescription);
            this.Controls.Add(this.txtCrCode);
            this.Controls.Add(this.txtDepartment);
            this.Controls.Add(this.pcbxProfessorImage);
            this.Name = "frmViewAllInformation";
            this.Text = "frmViewAllInformation";
            this.Load += new System.EventHandler(this.frmViewAllInformation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcbxProfessorImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.PictureBox pcbxProfessorImage;
        public System.Windows.Forms.TextBox txtDepartment;
        public System.Windows.Forms.TextBox txtCrCode;
        public System.Windows.Forms.RichTextBox rchtxtCrsDescription;
        public System.Windows.Forms.TextBox txtCrsTitle;
        public System.Windows.Forms.TextBox txtCrsCredits;
        public System.Windows.Forms.TextBox txtCrsPreRequisites;
        public System.Windows.Forms.TextBox txtFirstDay;
        public System.Windows.Forms.TextBox txtSecondDay;
        public System.Windows.Forms.TextBox txtThirdDay;
        public System.Windows.Forms.TextBox txtMaxSeats;
        public System.Windows.Forms.TextBox txtAvaliableSeats;
        public System.Windows.Forms.TextBox txtProfessorName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}