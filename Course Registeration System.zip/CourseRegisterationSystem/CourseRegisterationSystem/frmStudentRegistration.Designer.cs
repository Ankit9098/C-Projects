﻿namespace CourseRegisterationSystem
{
    partial class frmStudentRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtStudentID = new System.Windows.Forms.TextBox();
            this.txtStudentFirstName = new System.Windows.Forms.TextBox();
            this.txtStudentLastName = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbFallSemester = new System.Windows.Forms.RadioButton();
            this.rdbSummer2Semester = new System.Windows.Forms.RadioButton();
            this.rdbnSummer1Semester = new System.Windows.Forms.RadioButton();
            this.rdbSpringSemester = new System.Windows.Forms.RadioButton();
            this.lstvwRooster = new System.Windows.Forms.ListView();
            this.btnAddCourse = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnRegisteration = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lstvwCoursesRegistered = new System.Windows.Forms.ListView();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.txtRegisterationTime = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtStudentID
            // 
            this.txtStudentID.BackColor = System.Drawing.Color.White;
            this.txtStudentID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStudentID.Location = new System.Drawing.Point(614, 3);
            this.txtStudentID.Name = "txtStudentID";
            this.txtStudentID.Size = new System.Drawing.Size(154, 26);
            this.txtStudentID.TabIndex = 0;
            this.txtStudentID.Text = "909095176";
            // 
            // txtStudentFirstName
            // 
            this.txtStudentFirstName.BackColor = System.Drawing.Color.White;
            this.txtStudentFirstName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStudentFirstName.Location = new System.Drawing.Point(334, 3);
            this.txtStudentFirstName.Name = "txtStudentFirstName";
            this.txtStudentFirstName.Size = new System.Drawing.Size(154, 26);
            this.txtStudentFirstName.TabIndex = 1;
            this.txtStudentFirstName.Text = "King";
            // 
            // txtStudentLastName
            // 
            this.txtStudentLastName.BackColor = System.Drawing.Color.White;
            this.txtStudentLastName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStudentLastName.Location = new System.Drawing.Point(88, 3);
            this.txtStudentLastName.Name = "txtStudentLastName";
            this.txtStudentLastName.Size = new System.Drawing.Size(154, 26);
            this.txtStudentLastName.TabIndex = 2;
            this.txtStudentLastName.Text = "Larry";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.rdbFallSemester);
            this.groupBox1.Controls.Add(this.rdbSummer2Semester);
            this.groupBox1.Controls.Add(this.rdbnSummer1Semester);
            this.groupBox1.Controls.Add(this.rdbSpringSemester);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(774, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(179, 174);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select the semester";
            // 
            // rdbFallSemester
            // 
            this.rdbFallSemester.AutoSize = true;
            this.rdbFallSemester.Location = new System.Drawing.Point(7, 136);
            this.rdbFallSemester.Name = "rdbFallSemester";
            this.rdbFallSemester.Size = new System.Drawing.Size(49, 23);
            this.rdbFallSemester.TabIndex = 6;
            this.rdbFallSemester.TabStop = true;
            this.rdbFallSemester.Text = "Fall";
            this.rdbFallSemester.UseVisualStyleBackColor = true;
            // 
            // rdbSummer2Semester
            // 
            this.rdbSummer2Semester.AutoSize = true;
            this.rdbSummer2Semester.Location = new System.Drawing.Point(7, 99);
            this.rdbSummer2Semester.Name = "rdbSummer2Semester";
            this.rdbSummer2Semester.Size = new System.Drawing.Size(89, 23);
            this.rdbSummer2Semester.TabIndex = 5;
            this.rdbSummer2Semester.TabStop = true;
            this.rdbSummer2Semester.Text = "Summer 2";
            this.rdbSummer2Semester.UseVisualStyleBackColor = true;
            // 
            // rdbnSummer1Semester
            // 
            this.rdbnSummer1Semester.AutoSize = true;
            this.rdbnSummer1Semester.Location = new System.Drawing.Point(6, 66);
            this.rdbnSummer1Semester.Name = "rdbnSummer1Semester";
            this.rdbnSummer1Semester.Size = new System.Drawing.Size(89, 23);
            this.rdbnSummer1Semester.TabIndex = 4;
            this.rdbnSummer1Semester.TabStop = true;
            this.rdbnSummer1Semester.Text = "Summer 1";
            this.rdbnSummer1Semester.UseVisualStyleBackColor = true;
            // 
            // rdbSpringSemester
            // 
            this.rdbSpringSemester.AutoSize = true;
            this.rdbSpringSemester.Location = new System.Drawing.Point(7, 31);
            this.rdbSpringSemester.Name = "rdbSpringSemester";
            this.rdbSpringSemester.Size = new System.Drawing.Size(66, 23);
            this.rdbSpringSemester.TabIndex = 3;
            this.rdbSpringSemester.TabStop = true;
            this.rdbSpringSemester.Text = "Spring";
            this.rdbSpringSemester.UseVisualStyleBackColor = true;
            // 
            // lstvwRooster
            // 
            this.lstvwRooster.BackColor = System.Drawing.Color.White;
            this.lstvwRooster.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstvwRooster.FullRowSelect = true;
            this.lstvwRooster.HideSelection = false;
            this.lstvwRooster.Location = new System.Drawing.Point(3, 357);
            this.lstvwRooster.Name = "lstvwRooster";
            this.lstvwRooster.Size = new System.Drawing.Size(1167, 394);
            this.lstvwRooster.TabIndex = 8;
            this.lstvwRooster.UseCompatibleStateImageBehavior = false;
            // 
            // btnAddCourse
            // 
            this.btnAddCourse.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddCourse.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCourse.Location = new System.Drawing.Point(959, 3);
            this.btnAddCourse.Name = "btnAddCourse";
            this.btnAddCourse.Size = new System.Drawing.Size(172, 37);
            this.btnAddCourse.TabIndex = 10;
            this.btnAddCourse.Text = "Ad&d";
            this.btnAddCourse.UseVisualStyleBackColor = false;
            this.btnAddCourse.Click += new System.EventHandler(this.btnAddCourse_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnClose.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(1315, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(172, 37);
            this.btnClose.TabIndex = 12;
            this.btnClose.Text = "Clo&se";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnRegisteration
            // 
            this.btnRegisteration.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRegisteration.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegisteration.Location = new System.Drawing.Point(1137, 3);
            this.btnRegisteration.Name = "btnRegisteration";
            this.btnRegisteration.Size = new System.Drawing.Size(172, 37);
            this.btnRegisteration.TabIndex = 13;
            this.btnRegisteration.Text = "Reg&ister";
            this.btnRegisteration.UseVisualStyleBackColor = false;
            this.btnRegisteration.Click += new System.EventHandler(this.btnRegisteration_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(494, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 19);
            this.label1.TabIndex = 14;
            this.label1.Text = "Enter Student ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(248, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 19);
            this.label2.TabIndex = 15;
            this.label2.Text = "First Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 19);
            this.label3.TabIndex = 16;
            this.label3.Text = "Last Name:";
            // 
            // lstvwCoursesRegistered
            // 
            this.lstvwCoursesRegistered.BackColor = System.Drawing.Color.White;
            this.lstvwCoursesRegistered.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstvwCoursesRegistered.FullRowSelect = true;
            this.lstvwCoursesRegistered.HideSelection = false;
            this.lstvwCoursesRegistered.Location = new System.Drawing.Point(1493, 3);
            this.lstvwCoursesRegistered.Name = "lstvwCoursesRegistered";
            this.lstvwCoursesRegistered.Size = new System.Drawing.Size(762, 348);
            this.lstvwCoursesRegistered.TabIndex = 17;
            this.lstvwCoursesRegistered.UseCompatibleStateImageBehavior = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.label3);
            this.flowLayoutPanel1.Controls.Add(this.txtStudentLastName);
            this.flowLayoutPanel1.Controls.Add(this.label2);
            this.flowLayoutPanel1.Controls.Add(this.txtStudentFirstName);
            this.flowLayoutPanel1.Controls.Add(this.label1);
            this.flowLayoutPanel1.Controls.Add(this.txtStudentID);
            this.flowLayoutPanel1.Controls.Add(this.groupBox1);
            this.flowLayoutPanel1.Controls.Add(this.btnAddCourse);
            this.flowLayoutPanel1.Controls.Add(this.btnRegisteration);
            this.flowLayoutPanel1.Controls.Add(this.btnClose);
            this.flowLayoutPanel1.Controls.Add(this.lstvwCoursesRegistered);
            this.flowLayoutPanel1.Controls.Add(this.lstvwRooster);
            this.flowLayoutPanel1.Controls.Add(this.lblTotalCost);
            this.flowLayoutPanel1.Controls.Add(this.txtRegisterationTime);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(8, 13);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(2357, 858);
            this.flowLayoutPanel1.TabIndex = 18;
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.Location = new System.Drawing.Point(1176, 354);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(277, 86);
            this.lblTotalCost.TabIndex = 18;
            this.lblTotalCost.Text = "Total Cost for Semester";
            // 
            // txtRegisterationTime
            // 
            this.txtRegisterationTime.Location = new System.Drawing.Point(1459, 357);
            this.txtRegisterationTime.Name = "txtRegisterationTime";
            this.txtRegisterationTime.ReadOnly = true;
            this.txtRegisterationTime.Size = new System.Drawing.Size(100, 20);
            this.txtRegisterationTime.TabIndex = 19;
            // 
            // frmStudentRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(2615, 894);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "frmStudentRegistration";
            this.Text = "frmStudentRegistration";
            this.Load += new System.EventHandler(this.frmStudentRegistration_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtStudentID;
        private System.Windows.Forms.TextBox txtStudentFirstName;
        private System.Windows.Forms.TextBox txtStudentLastName;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbFallSemester;
        private System.Windows.Forms.RadioButton rdbSummer2Semester;
        private System.Windows.Forms.RadioButton rdbnSummer1Semester;
        private System.Windows.Forms.RadioButton rdbSpringSemester;
        private System.Windows.Forms.ListView lstvwRooster;
        private System.Windows.Forms.Button btnAddCourse;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnRegisteration;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView lstvwCoursesRegistered;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.TextBox txtRegisterationTime;
    }
}