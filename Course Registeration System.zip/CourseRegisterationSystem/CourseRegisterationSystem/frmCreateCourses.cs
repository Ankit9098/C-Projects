﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyClassLibrary;
using static MyClassLibrary.Course;

namespace CourseRegisterationSystem
{
    public partial class frmCreateCourses : Form
    {
        Course course;
        CourseList courseList;
        public int courseCreditHrs = 0;
        public frmCreateCourses()
        {
            InitializeComponent();
            courseList = new CourseList();
        }



        private void frmCreateCourses_Load(object sender, EventArgs e)
        {
            cboCourseDepartment.DataSource = courseList.GetDepartment();
            InitializeListView();
        }

        private void InitializeListView()
        {
            // Setting the view to show details
            listView1.View = View.Details;
            // Clearing the columns
            listView1.Columns.Clear();
            // Creating columns for the items and sub-items.
            // Width of -2 indicates auto-size.
            listView1.Columns.Add("Course Code", -2, HorizontalAlignment.Left);
            listView1.Columns.Add("Course Title", -2, HorizontalAlignment.Left);
            listView1.Columns.Add("Department", -2, HorizontalAlignment.Left);
            listView1.Columns.Add("Max Seats", -2, HorizontalAlignment.Left);
            listView1.Columns.Add("Available Seats", -2, HorizontalAlignment.Left);
            listView1.Columns.Add("Professor", -2, HorizontalAlignment.Left);

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string department = cboCourseDepartment.SelectedItem.ToString();
            string courseCode = txtCourseCode.Text.Trim();
            string courseTitle = txtCourseTitle.Text.Trim();
            string courseDescription = rchtxtCourseDescription.Text.Trim();
            string coursePreRequisites = txtCoursePreRequisites.Text.Trim();
            DateTime firstDayClassHeld = dtpFirstDayClassHeld.Value;
            DateTime secondDayClassHeld = dtpSecondDayClassHeld.Value;
            DateTime thirdDayClassHeld = dtpThirdDayClassHeld.Value;
            int courseMaxNumSeats = Convert.ToInt32(txtMaximumSeats.Text);
            int courseAvailableSeats = Convert.ToInt32(txtAvailableSeats.Text);
            string courseProfessorFullName = txtProfessorFullName.Text.Trim();
            string courseProfessorImgUrl = txtImageUrl.Text.Trim();

            Course newCourse = new Course(department, courseCode, courseTitle, courseDescription, courseCreditHrs,
                coursePreRequisites, firstDayClassHeld, secondDayClassHeld, thirdDayClassHeld, courseMaxNumSeats,
                courseAvailableSeats, courseProfessorFullName, courseProfessorImgUrl);

            if (courseList.AddCourse(newCourse, courseList.Count))
            {
                MessageBox.Show("Course added successfully.");
                UpdateCourseListView();
            }
            else
            {
                MessageBox.Show("Failed to add the course.");
            }
            List<Course> courses = courseList.GetSavedCourse();
            Console.WriteLine(courses.Count);



        }

        private void UpdateCourseListView()
        {
            listView1.Items.Clear();
            foreach (Course course in courseList.GetCourses())
            {
                ListViewItem item = new ListViewItem(new[]
                {
                    //Adding items onto the ListView item
                    course.CourseCode,
                    course.CourseTitle,
                    course.CourseDepartment.ToString(),
                    course.CourseMaxNumSeats.ToString(),
                    course.CourseAvailableSeats.ToString(),
                    course.CourseProfessorFullName
                });
                //Adding the items to the ListView.
                listView1.Items.Add(item);
            }
        }



        private void FindCreditSelected(object sender, EventArgs e)
        {
            if (rdb1Credit.Checked)
            {
                courseCreditHrs = 1;
            }
            else if (rdb3Credits.Checked)
            {
                courseCreditHrs = 3;
            }
            else if (rdb4Credits.Checked)
            {
                courseCreditHrs = 4;
            }
            else
            {
                MessageBox.Show("Please select the appropriate credits for this course");
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            frmCourseListing form2 = new frmCourseListing();
            form2.Show();
            this.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }





        private void CheckStringTextValues(object sender, CancelEventArgs e)
        {
            double value = 0;
            TextBox control = (TextBox)sender;
            if (string.IsNullOrEmpty(control.Text))
            {
                MessageBox.Show("The " + control.Name + " cannot be blank");
                e.Cancel = true;
            }
            else if (double.TryParse(control.Text, out value))
            {
                MessageBox.Show("The " + control.Name + "must be letters");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }

        private void CheckIntTextValues(object sender, CancelEventArgs e)
        {
            int value = 0;
            TextBox control = (TextBox)sender;

            if (string.IsNullOrEmpty(control.Text))
            {
                MessageBox.Show("The " + control.Name + " cannot be blank");
                e.Cancel = true;
            }
            else if (!int.TryParse(control.Text, out value))
            {
                MessageBox.Show("The " + control.Name + "must be numerical numbers");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }


        private void frmCreateCourses_FormClosing(object sender, FormClosingEventArgs e)
        {
            courseList.SaveCourses();
        }

    }
}
