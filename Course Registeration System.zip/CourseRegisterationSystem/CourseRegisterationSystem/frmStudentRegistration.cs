﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyClassLibrary;

namespace CourseRegisterationSystem
{
    public partial class frmStudentRegistration : Form
    {
        public StudentCourseRegistration str = new StudentCourseRegistration();

        public CourseList crl = new CourseList();

        public string studentSemester;
        public frmStudentRegistration()
        {
            InitializeComponent();
        }

        private void btnRegisteration_Click(object sender, EventArgs e)
        {

        }

        private void frmStudentRegistration_Load(object sender, EventArgs e)
        {
            lstvwRooster.View = View.Details;
            lstvwRooster.Columns.Add("Course Code", -2, HorizontalAlignment.Left);
            lstvwRooster.Columns.Add("First Day Class Held", -2, HorizontalAlignment.Left);
            lstvwRooster.Columns.Add("Second Day Class Held", -2, HorizontalAlignment.Left);
            lstvwRooster.Columns.Add("Third Day Class Held", -2, HorizontalAlignment.Left);
            lstvwRooster.Columns.Add("Professor", -2, HorizontalAlignment.Left);
            LoadCoursesIntoAListView();

            lstvwCoursesRegistered.Columns.Add("Course Code", 120, HorizontalAlignment.Left);
            lstvwCoursesRegistered.Columns.Add("Course Title", 200, HorizontalAlignment.Left);
            lstvwCoursesRegistered.Columns.Add("Department", 100, HorizontalAlignment.Left);
            lstvwCoursesRegistered.Columns.Add("First Day Class Held", 150, HorizontalAlignment.Left);
            lstvwCoursesRegistered.Columns.Add("Second Day Class Held", 150, HorizontalAlignment.Left);
            lstvwCoursesRegistered.Columns.Add("Third Day Class Held", 150, HorizontalAlignment.Left);
            lstvwCoursesRegistered.Columns.Add("Professor", 200, HorizontalAlignment.Left);

            // Setting the view to show details.
            lstvwCoursesRegistered.View = View.Details;
            txtRegisterationTime.Text = DateTime.Now.ToString("T");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LoadCoursesIntoAListView()
        {
            CourseList manager = new CourseList();
            List<Course> courses = manager.GetSavedCourse();

            foreach (Course course in courses)
            {
                if (course.CourseAvailableSeats >= 0)
                {
                    ListViewItem item = new ListViewItem(new[]
                    {
                        course.CourseCode,
                        course.FirstDayClassHeld.DayOfWeek.ToString(),
                        course.SecondDayClassHeld.DayOfWeek.ToString(),
                        course.ThirdDayClassHeld.DayOfWeek.ToString(),
                        course.CourseProfessorFullName,

                    });
                    lstvwRooster.Items.Add(item);
                }
            }

            lstvwRooster.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.ColumnContent);
        }


        private void FindSemester()
        {
            if (rdbFallSemester.Checked)
            {
                studentSemester = rdbFallSemester.Text;
            }
            else if (rdbSpringSemester.Checked)
            {
                studentSemester = rdbSpringSemester.Text;
            }
            else if (rdbnSummer1Semester.Checked)
            {
                studentSemester = rdbnSummer1Semester.Text;
            }
            else if (rdbSummer2Semester.Checked)
            {
                studentSemester = rdbSummer2Semester.Text;
            }
        }

        private void btnAddCourse_Click(object sender, EventArgs e)
        {
            FindSemester();
            string studentId = txtStudentID.Text;
            string studentFirstName = txtStudentFirstName.Text;
            string studentLastName = txtStudentLastName.Text;

            if (lstvwRooster.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a course.");
                return;
            }
            string selectedCourseCode = lstvwRooster.SelectedItems[0].Text;
            List<Course> updatedRegisteredCourses = str.AddCourseByCode(selectedCourseCode, crl);


            UpdateCoursesRegisteredListView(updatedRegisteredCourses);
            double totalCost = str.CalculateSemesterCost();
            lblTotalCost.Text = "Total Cost for Semester: " + totalCost.ToString("C");

        }

        private void UpdateCoursesRegisteredListView(List<Course> courses)
        {
            lstvwCoursesRegistered.Items.Clear();

            foreach (Course course in courses)
            {
                ListViewItem item = new ListViewItem(new[]
                {
                    course.CourseCode,
                    course.CourseTitle,
                    course.CourseDepartment,
                    course.FirstDayClassHeld.DayOfWeek.ToString(),
                    course.SecondDayClassHeld.DayOfWeek.ToString(),
                    course.ThirdDayClassHeld.DayOfWeek.ToString(),
                    course.CourseProfessorFullName,
                });
                lstvwCoursesRegistered.Items.Add(item);
            }
        }

    }
}
