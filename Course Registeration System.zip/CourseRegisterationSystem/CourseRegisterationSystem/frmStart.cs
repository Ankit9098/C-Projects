﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseRegisterationSystem
{
    public partial class frmStart : Form
    {
        public frmStart()
        {
            InitializeComponent();
        }

        private void btnCreateCourse_Click(object sender, EventArgs e)
        {
            Form frmMain = new frmCreateCourses();
            frmMain.ShowDialog();
        }

        private void btnViewCourses_Click(object sender, EventArgs e)
        {
            Form frmCourseListing = new frmCourseListing();
            frmCourseListing.ShowDialog();
        }

        private void btnStudentRegisteration_Click(object sender, EventArgs e)
        {
            Form frmStudentRegistration = new frmStudentRegistration();
            frmStudentRegistration.ShowDialog();
        }
    }
}
