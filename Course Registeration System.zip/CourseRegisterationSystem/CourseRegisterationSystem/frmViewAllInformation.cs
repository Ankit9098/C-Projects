﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseRegisterationSystem
{
    public partial class frmViewAllInformation : Form
    {
        private frmCourseListing ownerForm;
        public frmViewAllInformation()
        {
            InitializeComponent();
        }

        private void frmViewAllInformation_Load(object sender, EventArgs e)
        {

        }

        public void SetOwner(Form theForm)
        {
            // Cast the form to the correct class.
            ownerForm = (frmCourseListing)theForm;
        }

    }
}
