﻿namespace CourseRegisterationSystem
{
    partial class frmStart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCreateCourse = new System.Windows.Forms.Button();
            this.btnViewCourses = new System.Windows.Forms.Button();
            this.btnStudentRegisteration = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCreateCourse
            // 
            this.btnCreateCourse.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCreateCourse.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateCourse.ForeColor = System.Drawing.Color.Black;
            this.btnCreateCourse.Location = new System.Drawing.Point(12, 23);
            this.btnCreateCourse.Name = "btnCreateCourse";
            this.btnCreateCourse.Size = new System.Drawing.Size(420, 56);
            this.btnCreateCourse.TabIndex = 0;
            this.btnCreateCourse.Text = "&Create Course";
            this.btnCreateCourse.UseVisualStyleBackColor = false;
            this.btnCreateCourse.Click += new System.EventHandler(this.btnCreateCourse_Click);
            // 
            // btnViewCourses
            // 
            this.btnViewCourses.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnViewCourses.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewCourses.ForeColor = System.Drawing.Color.Black;
            this.btnViewCourses.Location = new System.Drawing.Point(12, 160);
            this.btnViewCourses.Name = "btnViewCourses";
            this.btnViewCourses.Size = new System.Drawing.Size(420, 56);
            this.btnViewCourses.TabIndex = 1;
            this.btnViewCourses.Text = "&View All Courses";
            this.btnViewCourses.UseVisualStyleBackColor = false;
            this.btnViewCourses.Click += new System.EventHandler(this.btnViewCourses_Click);
            // 
            // btnStudentRegisteration
            // 
            this.btnStudentRegisteration.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnStudentRegisteration.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStudentRegisteration.ForeColor = System.Drawing.Color.Black;
            this.btnStudentRegisteration.Location = new System.Drawing.Point(12, 301);
            this.btnStudentRegisteration.Name = "btnStudentRegisteration";
            this.btnStudentRegisteration.Size = new System.Drawing.Size(420, 56);
            this.btnStudentRegisteration.TabIndex = 2;
            this.btnStudentRegisteration.Text = "Student &Registeration";
            this.btnStudentRegisteration.UseVisualStyleBackColor = false;
            this.btnStudentRegisteration.Click += new System.EventHandler(this.btnStudentRegisteration_Click);
            // 
            // frmStart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(494, 472);
            this.Controls.Add(this.btnStudentRegisteration);
            this.Controls.Add(this.btnViewCourses);
            this.Controls.Add(this.btnCreateCourse);
            this.Name = "frmStart";
            this.Text = "frmStart";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCreateCourse;
        private System.Windows.Forms.Button btnViewCourses;
        private System.Windows.Forms.Button btnStudentRegisteration;
    }
}