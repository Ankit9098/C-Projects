﻿using MyClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CourseRegisterationSystem
{
    public partial class frmCourseListing : Form
    {
        CourseList courseList = new CourseList();

        public frmCourseListing()
        {
            InitializeComponent();
            lstvwSummaryInformation.View = View.Details;
            lstvwSummaryInformation.Columns.Add("Course Code", -2, HorizontalAlignment.Left);
            lstvwSummaryInformation.Columns.Add("First Day Class Held", -2, HorizontalAlignment.Left);
            lstvwSummaryInformation.Columns.Add("Second Day Class Held", -2, HorizontalAlignment.Left);
            lstvwSummaryInformation.Columns.Add("Third Day Class Held", -2, HorizontalAlignment.Left);
            lstvwSummaryInformation.Columns.Add("Professor", -2, HorizontalAlignment.Left);
        }

        private void frmCourseListing_Load(object sender, EventArgs e)
        {
            courseList = new CourseList();
            comboBox1.DataSource = courseList.GetDepartment();
            courseList.GetCourses();
            LoadCoursesIntoAListView();
        }


        public void LoadCoursesIntoAListView()
        {
            CourseList manager = new CourseList();
            List<Course> courses = manager.GetSavedCourse();



            foreach (var course in courses)
            {
                ListViewItem item = new ListViewItem(new[]
                {
                    course.CourseCode,
                    course.FirstDayClassHeld.DayOfWeek.ToString(),
                    course.SecondDayClassHeld.DayOfWeek.ToString(),
                    course.ThirdDayClassHeld.DayOfWeek.ToString(),
                    course.CourseProfessorFullName,

                });
                lstvwSummaryInformation.Items.Add(item);
            }

            lstvwSummaryInformation.AutoResizeColumn(0,ColumnHeaderAutoResizeStyle.ColumnContent);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string department = comboBox1.SelectedItem.ToString();
            CourseList list = new CourseList();
            List<Course> courses = list.SearchCourseByDepartment(department);

            lstvwSummaryInformation.Items.Clear();

            foreach (Course course in courses)
            {
                ListViewItem item = new ListViewItem(new string[] {

                    course.CourseCode,
                    course.FirstDayClassHeld.DayOfWeek.ToString(),
                    course.SecondDayClassHeld.DayOfWeek.ToString(),
                    course.ThirdDayClassHeld.DayOfWeek.ToString(),
                    course.CourseMaxNumSeats.ToString(),
                    course.CourseAvailableSeats.ToString(),
                    course.CourseProfessorFullName,
                    course.CourseDepartment,
                    course.CourseTitle,
                    course.CourseDescription,
                    course.CourseCreditHrs.ToString(),
                    course.CoursePreRequisites

                });
                lstvwSummaryInformation.Items.Add(item);
            }

            lstvwSummaryInformation.AutoResizeColumn(0,ColumnHeaderAutoResizeStyle.ColumnContent);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            if (lstvwSummaryInformation.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a course from the list.");
                return;
            }
            string courseCode = lstvwSummaryInformation.SelectedItems[0].Text;
            frmViewAllInformation viewAllInformation = new frmViewAllInformation();
            viewAllInformation.SetOwner(this);
            List<Course> courseSearched = courseList.SearchCourseByCourseCode(courseCode);
            foreach (Course course in courseSearched)
            {

                viewAllInformation.txtDepartment.Text = course.CourseDepartment;
                viewAllInformation.txtCrCode.Text = course.CourseCode;
                viewAllInformation.txtCrsTitle.Text = course.CourseTitle;
                viewAllInformation.rchtxtCrsDescription.Text = course.CourseDescription;
                viewAllInformation.txtCrsCredits.Text = course.CourseCreditHrs.ToString();
                viewAllInformation.txtCrsPreRequisites.Text = course.CoursePreRequisites;
                viewAllInformation.txtFirstDay.Text = course.FirstDayClassHeld.DayOfWeek.ToString();
                viewAllInformation.txtSecondDay.Text = course.SecondDayClassHeld.DayOfWeek.ToString();
                viewAllInformation.txtThirdDay.Text = course.ThirdDayClassHeld.DayOfWeek.ToString();
                viewAllInformation.txtMaxSeats.Text = course.CourseMaxNumSeats.ToString();
                viewAllInformation.txtAvaliableSeats.Text = course.CourseAvailableSeats.ToString();
                viewAllInformation.txtProfessorName.Text = course.CourseProfessorFullName;
                viewAllInformation.pcbxProfessorImage.Load(course.CourseProfessorImgUrl);
            }
            viewAllInformation.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmCreateCourses form1  =new frmCreateCourses();
            form1.Show();
            this.Close();
        }
    }
}