﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static MyClassLibrary.Course;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ListView = System.Windows.Forms.ListView;

namespace MyClassLibrary
{
    public class CourseList
    {
        private List<Course> coursesRoster;
        private int currentPosition;
        private List<string> Department;
        public List<Course> courseAvailable;

        public CourseList()
        {
            coursesRoster = new List<Course>();
            Department = new List<string>();
            courseAvailable = new List<Course>();
            currentPosition = -1;
            Department.Add("CIS");
            Department.Add("CHE");
            Department.Add("MAT");
            Department.Add("BUS");
            Department.Add("BIO");
            Department.Add("PHY");
            Department.Add("ENG");
            Department.Add("LIT");
            Department.Add("PSY");
            Department.Add("SOC");
        }

        public int Count
        {
            get { return coursesRoster.Count; }
        }


        public void AddCourse(Course course)
        {
            coursesRoster.Add(course);
        }

        public bool AddCourse(Course course, int index)
        {
            if (index >= 0 && index <= coursesRoster.Count)
            {
                coursesRoster.Insert(index, course);
                return true;
            }

            return false;
        }


        public List<Course> GetCourses()
        {
            return new List<Course>(coursesRoster);
        }

        public List<String> GetDepartment()
        {
            return new List<String>(Department);
        }


        public List<Course> SearchCourseByDepartment(string department)
        {
            List<Course> filteredCourses = new List<Course>();
            List<Course> courseList = GetSavedCourse();
            foreach (Course course in courseList)
            {
                if (course.CourseDepartment == department)
                {
                    filteredCourses.Add(course);
                }
            }
            return filteredCourses;
        }

        public List<Course> SearchCourseByCourseCode(string courseCode)
        {
            List<Course> selectedCourse = new List<Course>();
            List<Course> courseList = GetSavedCourse();
            foreach (Course course in courseList)
            {
                if (course.CourseCode == courseCode)
                {
                    selectedCourse.Add(course);
                }
            }
            return selectedCourse;
        }

        /*
         * using FileStream to open or create the file using append to addonto the file and using access write to allow to write data onto this text file.
         * using a "using" statement which will automatically open and close the text file
         * Created a StreamWriter that writes to write your courses on to the file.
         */

        public void SaveCourses()
        {
            using (StreamWriter textOut = new StreamWriter(new FileStream("Courses.txt", FileMode.Append, FileAccess.Write)))
            {
                foreach (Course course in coursesRoster)
                {
                    textOut.Write(course.CourseDepartment + "|");
                    textOut.Write(course.CourseCode + "|");
                    textOut.Write(course.CourseTitle + "|");
                    textOut.Write(course.CourseDescription + "|");
                    textOut.Write(course.CourseCreditHrs + "|");
                    textOut.Write(course.CoursePreRequisites + "|");
                    textOut.Write(course.FirstDayClassHeld + "|");
                    textOut.Write(course.SecondDayClassHeld + "|");
                    textOut.Write(course.ThirdDayClassHeld + "|");
                    textOut.Write(course.CourseMaxNumSeats + "|");
                    textOut.Write(course.CourseAvailableSeats + "|");
                    textOut.Write(course.CourseProfessorFullName + "|");
                    textOut.WriteLine(course.CourseProfessorImgUrl);
                }
            }
        }

        /*
         * Doing the same thing here just using a streamredare reading the file.
         * Then Parse each column and seprating them with | into a Course object
         * Used a using to automatically close and open the file
         * Finally adding them into the courseList which a collection in the Course. And into courseAvaliable so it can be used for obnly shwoing avaliable courses inthe student course regisetration
         */
        public List<Course> GetSavedCourse()
        {
            using (StreamReader textIn =
                   new StreamReader(new FileStream("Courses.txt", FileMode.OpenOrCreate, FileAccess.Read)))
            {
                List<Course> courseList = new List<Course>();

                while (textIn.Peek() != -1)
                {
                    string row = textIn.ReadLine() ?? "";
                    string[] columns = row.Split('|');
                    if (columns.Length == 13)
                    {
                        Course course = new Course
                        {
                            CourseDepartment = columns[0],
                            CourseCode = columns[1],
                            CourseTitle = columns[2],
                            CourseDescription = columns[3],
                            CourseCreditHrs = Convert.ToInt16(columns[4]),
                            CoursePreRequisites = columns[5],
                            FirstDayClassHeld = DateTime.Parse(columns[6]),
                            SecondDayClassHeld = DateTime.Parse(columns[7]),
                            ThirdDayClassHeld = DateTime.Parse(columns[8]),
                            CourseMaxNumSeats = Convert.ToInt16(columns[9]),
                            CourseAvailableSeats = Convert.ToInt16(columns[10]),
                            CourseProfessorFullName = columns[11],
                            CourseProfessorImgUrl = columns[12]
                        };
                        courseList.Add(course);
                        if (course.CourseAvailableSeats > 0)
                        {
                            courseAvailable.Add(course);
                        }
                    }
                }
                return courseList;
            }
        }
    }
}
