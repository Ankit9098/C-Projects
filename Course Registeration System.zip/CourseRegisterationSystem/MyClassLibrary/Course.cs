﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static MyClassLibrary.Course;

namespace MyClassLibrary
{
    public class Course
    {

        private string courseDepartment;
        private string courseCode;
        private string courseTitle;
        private string courseDescription;
        private int courseCreditHrs;
        private string coursePreRequisites;
        private DateTime firstDayClassHeld;
        private DateTime secondDayClassHeld;
        private DateTime thirdDayClassHeld;
        private int courseMaxNumSeats;
        private int courseAvailableSeats;
        private string courseProfessorFullName;
        private string courseProfessorImgURL;
        internal string courseProfessorImgUrl;
        public List<string> EnrolledStudentIds;
        public Course()
        {
            this.EnrolledStudentIds = new List<string>();
        }

        public Course(string courseDepartment, string courseCode, string courseTitle, string courseDescription, int courseCreditHrs,
            string coursePreRequisites, DateTime firstDayClassHeld, DateTime secondDayClassHeld, DateTime thirdDayClassHeld, int courseMaxNumSeats,
            int courseAvailableSeats, string courseProfessorFullName, string courseProfessorImgURL)
        {
            this.courseDepartment = courseDepartment;
            this.courseCode = courseCode;
            this.courseTitle = courseTitle;
            this.courseDescription = courseDescription;
            this.courseCreditHrs = courseCreditHrs;
            this.coursePreRequisites = coursePreRequisites;
            this.firstDayClassHeld = firstDayClassHeld;
            this.secondDayClassHeld = secondDayClassHeld;
            this.thirdDayClassHeld = thirdDayClassHeld;
            this.courseMaxNumSeats = courseMaxNumSeats;
            this.courseAvailableSeats = courseAvailableSeats;
            this.courseProfessorFullName = courseProfessorFullName;
            this.courseProfessorImgURL = courseProfessorImgURL;
        }

        public String CourseDepartment
        {
            get { return courseDepartment; }
            set { courseDepartment = value; }
        }

        public String CourseCode
        {
            get { return courseCode; }
            set { courseCode = value; }
        }

        public String CourseTitle
        {
            get { return courseTitle; }
            set { courseTitle = value; }
        }

        public String CourseDescription
        {
            get { return courseDescription; }
            set { courseDescription = value; }
        }

        public int CourseCreditHrs
        {
            get { return courseCreditHrs; }
            set { courseCreditHrs = value; }
        }

        public String CoursePreRequisites
        {
            get { return coursePreRequisites; }
            set { coursePreRequisites = value; }
        }

        public DateTime FirstDayClassHeld
        {
            get { return firstDayClassHeld; }
            set { firstDayClassHeld = value; }
        }

        public DateTime SecondDayClassHeld
        {
            get { return secondDayClassHeld; }
            set { secondDayClassHeld = value; }
        }

        public DateTime ThirdDayClassHeld
        {
            get { return thirdDayClassHeld; }
            set { thirdDayClassHeld = value; }
        }

        public int CourseMaxNumSeats
        {
            get { return courseMaxNumSeats; }
            set { courseMaxNumSeats = value; }
        }

        public int CourseAvailableSeats
        {
            get { return courseAvailableSeats; }
            set { courseAvailableSeats = value; }
        }

        public String CourseProfessorFullName
        {
            get { return courseProfessorFullName; }
            set { courseProfessorFullName = value; }
        }

        public String CourseProfessorImgUrl
        {
            get { return courseProfessorImgURL; }
            set { courseProfessorImgURL = value; }
        }


    }
}
