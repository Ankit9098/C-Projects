﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClassLibrary
{
    public class StudentCourseRegistration
    {
        private const double CostCredit = 1000.00;
        private string studentID;

        private string studentFirstName;
        private string studentLastName;

        private string semester;
        public List<Course> studentRegisteredCourses;
        private DateTime dateTimeForRegisertation;

        public StudentCourseRegistration()
        {
            this.studentRegisteredCourses = new List<Course>();
        }

        public StudentCourseRegistration(string studentID, string studentFirstName, string studentLastName,
            string semester, DateTime dateTimeForRegisertation)
        {
            this.studentID = studentID;
            this.studentFirstName = studentFirstName;
            this.studentLastName = studentLastName;
            this.semester = semester;
            this.dateTimeForRegisertation = dateTimeForRegisertation;
        }

        public String StudentId
        {
            get { return studentID; }
            set { this.studentID = value; }
        }

        public string StudentFirstName
        {
            get { return studentFirstName; }
            set { this.studentFirstName = value; }
        }

        public string StudentLastName
        {
            get { return studentLastName; }
            set { this.studentLastName = value; }
        }

        public String StudentSemester
        {
            get { return semester; }
            set { this.semester = value; }
        }

        public DateTime DateTimeForRegisertation
        {
            get { return dateTimeForRegisertation; }
            set { dateTimeForRegisertation = value;}
        }

        public List<Course> AddCourseByCode(string courseCode, CourseList courseList)
        {
            var courses = courseList.SearchCourseByCourseCode(courseCode);
            if (courses.Count > 0)
            {
                Course courseToAdd = courses[0];
                if (courseToAdd.CourseAvailableSeats > 0 && !studentRegisteredCourses.Contains(courseToAdd))
                {
                    this.studentRegisteredCourses.Add(courseToAdd);
                    courseToAdd.CourseAvailableSeats--;
                }
            }

            return new List<Course>(this.studentRegisteredCourses); 
        }

        public double CalculateSemesterCost()
        {
            double totalCost = 0;
            foreach (Course course in this.studentRegisteredCourses)
            {
                totalCost += course.CourseCreditHrs * CostCredit;
            }
            return totalCost;
        }
    }
}
