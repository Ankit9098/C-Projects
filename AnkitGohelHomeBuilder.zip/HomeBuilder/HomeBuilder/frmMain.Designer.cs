﻿namespace HomeBuilder
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.cmbHomePlan = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.picbxHomeFront = new System.Windows.Forms.PictureBox();
            this.picbxHomePlan = new System.Windows.Forms.PictureBox();
            this.rchtxtHousePlanInformation = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbnClayTiles = new System.Windows.Forms.RadioButton();
            this.rdbnMetal = new System.Windows.Forms.RadioButton();
            this.rdbnShingles = new System.Windows.Forms.RadioButton();
            this.chklbAdditionalOptions = new System.Windows.Forms.CheckedListBox();
            this.cmbCountertopMaterial = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chckWood = new System.Windows.Forms.CheckBox();
            this.chckCarpet = new System.Windows.Forms.CheckBox();
            this.chckTile = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblHomeSqrFeet = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picbxHomeFront)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbxHomePlan)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(74, 22);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 0;
            this.txtName.Text = "Ankit Gohel";
            this.txtName.Validating += new System.ComponentModel.CancelEventHandler(this.CheckStringTextValues);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Phone";
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(74, 81);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(100, 20);
            this.txtPhone.TabIndex = 1;
            this.txtPhone.Text = "4018098312";
            this.txtPhone.Validating += new System.ComponentModel.CancelEventHandler(this.CheckDoubleTextValues);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Address";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(74, 141);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(100, 20);
            this.txtAddress.TabIndex = 2;
            this.txtAddress.Text = "2089 Ivery Avenue Philadelphia";
            this.txtAddress.Validating += new System.ComponentModel.CancelEventHandler(this.CheckStringTextValues);
            // 
            // cmbHomePlan
            // 
            this.cmbHomePlan.FormattingEnabled = true;
            this.cmbHomePlan.Location = new System.Drawing.Point(180, 216);
            this.cmbHomePlan.Name = "cmbHomePlan";
            this.cmbHomePlan.Size = new System.Drawing.Size(279, 21);
            this.cmbHomePlan.TabIndex = 6;
            this.cmbHomePlan.SelectedIndexChanged += new System.EventHandler(this.cmbHomePlan_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(32, 219);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "Please select a Home Plan";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // picbxHomeFront
            // 
            this.picbxHomeFront.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picbxHomeFront.Location = new System.Drawing.Point(541, 82);
            this.picbxHomeFront.Name = "picbxHomeFront";
            this.picbxHomeFront.Size = new System.Drawing.Size(319, 259);
            this.picbxHomeFront.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picbxHomeFront.TabIndex = 8;
            this.picbxHomeFront.TabStop = false;
            // 
            // picbxHomePlan
            // 
            this.picbxHomePlan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picbxHomePlan.Location = new System.Drawing.Point(541, 390);
            this.picbxHomePlan.Name = "picbxHomePlan";
            this.picbxHomePlan.Size = new System.Drawing.Size(319, 259);
            this.picbxHomePlan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picbxHomePlan.TabIndex = 9;
            this.picbxHomePlan.TabStop = false;
            // 
            // rchtxtHousePlanInformation
            // 
            this.rchtxtHousePlanInformation.Location = new System.Drawing.Point(75, 256);
            this.rchtxtHousePlanInformation.Name = "rchtxtHousePlanInformation";
            this.rchtxtHousePlanInformation.ReadOnly = true;
            this.rchtxtHousePlanInformation.Size = new System.Drawing.Size(341, 235);
            this.rchtxtHousePlanInformation.TabIndex = 10;
            this.rchtxtHousePlanInformation.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbnClayTiles);
            this.groupBox1.Controls.Add(this.rdbnMetal);
            this.groupBox1.Controls.Add(this.rdbnShingles);
            this.groupBox1.Location = new System.Drawing.Point(11, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(308, 149);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Please select the type of Roof: Price per sqrft";
            // 
            // rdbnClayTiles
            // 
            this.rdbnClayTiles.AutoSize = true;
            this.rdbnClayTiles.Location = new System.Drawing.Point(6, 109);
            this.rdbnClayTiles.Name = "rdbnClayTiles";
            this.rdbnClayTiles.Size = new System.Drawing.Size(70, 17);
            this.rdbnClayTiles.TabIndex = 2;
            this.rdbnClayTiles.TabStop = true;
            this.rdbnClayTiles.Text = "Clay Tiles";
            this.rdbnClayTiles.UseVisualStyleBackColor = true;
            // 
            // rdbnMetal
            // 
            this.rdbnMetal.AutoSize = true;
            this.rdbnMetal.Location = new System.Drawing.Point(6, 74);
            this.rdbnMetal.Name = "rdbnMetal";
            this.rdbnMetal.Size = new System.Drawing.Size(51, 17);
            this.rdbnMetal.TabIndex = 1;
            this.rdbnMetal.TabStop = true;
            this.rdbnMetal.Text = "Metal";
            this.rdbnMetal.UseVisualStyleBackColor = true;
            // 
            // rdbnShingles
            // 
            this.rdbnShingles.AutoSize = true;
            this.rdbnShingles.Location = new System.Drawing.Point(6, 41);
            this.rdbnShingles.Name = "rdbnShingles";
            this.rdbnShingles.Size = new System.Drawing.Size(65, 17);
            this.rdbnShingles.TabIndex = 0;
            this.rdbnShingles.TabStop = true;
            this.rdbnShingles.Text = "Shingles";
            this.rdbnShingles.UseVisualStyleBackColor = true;
            // 
            // chklbAdditionalOptions
            // 
            this.chklbAdditionalOptions.FormattingEnabled = true;
            this.chklbAdditionalOptions.Location = new System.Drawing.Point(306, 255);
            this.chklbAdditionalOptions.Name = "chklbAdditionalOptions";
            this.chklbAdditionalOptions.Size = new System.Drawing.Size(280, 154);
            this.chklbAdditionalOptions.TabIndex = 12;
            // 
            // cmbCountertopMaterial
            // 
            this.cmbCountertopMaterial.FormattingEnabled = true;
            this.cmbCountertopMaterial.Items.AddRange(new object[] {
            "Formica",
            "Wood",
            "Granite",
            "Quartz"});
            this.cmbCountertopMaterial.Location = new System.Drawing.Point(215, 182);
            this.cmbCountertopMaterial.Name = "cmbCountertopMaterial";
            this.cmbCountertopMaterial.Size = new System.Drawing.Size(198, 21);
            this.cmbCountertopMaterial.TabIndex = 13;
            this.cmbCountertopMaterial.SelectedIndexChanged += new System.EventHandler(this.cmbCountertopMaterial_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(8, 182);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(201, 21);
            this.label5.TabIndex = 14;
            this.label5.Text = "Please select kitchen countertop material";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chckWood);
            this.groupBox2.Controls.Add(this.chckCarpet);
            this.groupBox2.Controls.Add(this.chckTile);
            this.groupBox2.Location = new System.Drawing.Point(11, 231);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(232, 218);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Please Select your Floor Coverings : Price per sqrft";
            // 
            // chckWood
            // 
            this.chckWood.AutoSize = true;
            this.chckWood.Location = new System.Drawing.Point(6, 119);
            this.chckWood.Name = "chckWood";
            this.chckWood.Size = new System.Drawing.Size(55, 17);
            this.chckWood.TabIndex = 2;
            this.chckWood.Text = "Wood";
            this.chckWood.UseVisualStyleBackColor = true;
            this.chckWood.CheckedChanged += new System.EventHandler(this.FindSelectedFloorMaterial);
            // 
            // chckCarpet
            // 
            this.chckCarpet.AutoSize = true;
            this.chckCarpet.Location = new System.Drawing.Point(6, 81);
            this.chckCarpet.Name = "chckCarpet";
            this.chckCarpet.Size = new System.Drawing.Size(57, 17);
            this.chckCarpet.TabIndex = 1;
            this.chckCarpet.Text = "Carpet";
            this.chckCarpet.UseVisualStyleBackColor = true;
            this.chckCarpet.CheckedChanged += new System.EventHandler(this.FindSelectedFloorMaterial);
            // 
            // chckTile
            // 
            this.chckTile.AutoSize = true;
            this.chckTile.Location = new System.Drawing.Point(6, 40);
            this.chckTile.Name = "chckTile";
            this.chckTile.Size = new System.Drawing.Size(43, 17);
            this.chckTile.TabIndex = 0;
            this.chckTile.Text = "Tile";
            this.chckTile.UseVisualStyleBackColor = true;
            this.chckTile.CheckedChanged += new System.EventHandler(this.FindSelectedFloorMaterial);
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(330, 231);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(182, 21);
            this.label6.TabIndex = 16;
            this.label6.Text = "Please select any additional options:";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(28, 597);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(236, 52);
            this.btnSubmit.TabIndex = 17;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(278, 596);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(236, 52);
            this.btnClose.TabIndex = 18;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblHomeSqrFeet
            // 
            this.lblHomeSqrFeet.AutoSize = true;
            this.lblHomeSqrFeet.Location = new System.Drawing.Point(177, 502);
            this.lblHomeSqrFeet.Name = "lblHomeSqrFeet";
            this.lblHomeSqrFeet.Size = new System.Drawing.Size(35, 13);
            this.lblHomeSqrFeet.TabIndex = 19;
            this.lblHomeSqrFeet.Text = "label7";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(72, 502);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Total sq/ft:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.cmbCountertopMaterial);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.btnClose);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.chklbAdditionalOptions);
            this.panel2.Controls.Add(this.btnSubmit);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(923, 675);
            this.panel2.TabIndex = 22;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.txtAddress);
            this.panel1.Controls.Add(this.lblHomeSqrFeet);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.rchtxtHousePlanInformation);
            this.panel1.Controls.Add(this.txtPhone);
            this.panel1.Controls.Add(this.picbxHomePlan);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtName);
            this.panel1.Controls.Add(this.picbxHomeFront);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.cmbHomePlan);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(920, 675);
            this.panel1.TabIndex = 23;
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(262, 729);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(236, 52);
            this.btnPrevious.TabIndex = 25;
            this.btnPrevious.Text = "Pre&vious";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(12, 730);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(236, 52);
            this.btnNext.TabIndex = 24;
            this.btnNext.Text = "N&ext";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2675, 921);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "frmMain";
            this.Text = "Ankit Gohel  - Home Builder";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picbxHomeFront)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbxHomePlan)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.ComboBox cmbHomePlan;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox picbxHomeFront;
        private System.Windows.Forms.PictureBox picbxHomePlan;
        private System.Windows.Forms.RichTextBox rchtxtHousePlanInformation;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbnClayTiles;
        private System.Windows.Forms.RadioButton rdbnMetal;
        private System.Windows.Forms.RadioButton rdbnShingles;
        private System.Windows.Forms.CheckedListBox chklbAdditionalOptions;
        private System.Windows.Forms.ComboBox cmbCountertopMaterial;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chckWood;
        private System.Windows.Forms.CheckBox chckCarpet;
        private System.Windows.Forms.CheckBox chckTile;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblHomeSqrFeet;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
    }
}

