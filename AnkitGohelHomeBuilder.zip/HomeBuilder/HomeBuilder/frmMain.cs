﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeBuilder
{
    public partial class frmMain : Form
    {
        private ArrayList selectedAddOns = new ArrayList();
        private frmReceipt receipt = new frmReceipt();
        public string selectedCountertopMaterial = "";
        public string selectedRoofMaterial = "";
        public string selectedFloorMaterial = "";
        private Home createHome;
        private PurchaseTransaction createPurchaseTransaction;
        List<Panel> listPanel = new List<Panel>();
        int index = 0;

        public frmMain()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            bool isValidRoof;
            bool isValidFloor;
            isValidRoof = FindingSelectedRoof();
            isValidFloor = FindingIfFloorMaterialsSelected();
            if (isValidRoof == false)
            {
                MessageBox.Show("Error Please select 1 roof option");
                return;
            }

            if (isValidFloor == false)
            {
                MessageBox.Show("Error Please select 1 floor option");
                return;
            }
            double homesqrft = double.Parse(lblHomeSqrFeet.Text);

            string name = txtName.Text;
            string address = txtAddress.Text;
            double phoneNumber = double.Parse(txtPhone.Text);

            string selectedHomeBuild = cmbHomePlan.Text;
            createHome = new Home(selectedHomeBuild, selectedRoofMaterial, selectedCountertopMaterial, selectedFloorMaterial);

            double selectedHomeBuildCost = createHome.GetHomePlanCost(selectedHomeBuild);
            double selectedCountertopMaterialCost =
               createHome.GetHomeCountertopMaterialPrice(selectedCountertopMaterial);
            double selectedRoofMaterialCost = createHome.GetHomeRoofCost(selectedRoofMaterial, homesqrft);
            double selectedFloorMaterialCost = createHome.GetHomeFloorCoveringsCost(selectedFloorMaterial, homesqrft);
            string userSelectedAddOns = GetSelectedItems(selectedAddOns, chklbAdditionalOptions);
            double selectedAddOnsCost = createHome.GetAddOnPrice(selectedAddOns);

            HomeBuyer homeBuyer = new HomeBuyer(name, address, phoneNumber);

            PurchaseTransaction purchase = new PurchaseTransaction();
            createPurchaseTransaction = new PurchaseTransaction(selectedHomeBuildCost, selectedRoofMaterialCost, selectedCountertopMaterialCost, selectedFloorMaterialCost, selectedAddOnsCost, selectedHomeBuild, selectedRoofMaterial, selectedCountertopMaterial, selectedFloorMaterial, selectedAddOns);
            receipt.rchtxtReciptInfo.Text = homeBuyer.ToString() + "\n" + createPurchaseTransaction.ToString();
            receipt.ShowDialog();
        }

        private void cmbHomePlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbHomePlan.Text == "The Modern Minimalist => $300,000.00")
            {
                picbxHomeFront.Load("https://cdn.houseplansservices.com/product/2lj0v0oapsuago4brao4su8ffr/w800x533.jpg?v=4");
                picbxHomePlan.Load("https://cdn.houseplansservices.com/product/gngtnndf9b4g8kvlqt3q19tesv/w600.jpg?v=4");
                rchtxtHousePlanInformation.Text = "";
                rchtxtHousePlanInformation.Text = "Bedrooms : 4\r\n" + "Stories: 2\r\n" + "Baths : 4.5\r\n" + "Garages: 3\r\n" + "Garage : 1167 sq/ft\r\n" + "Main Floor : 3137 sq/ft\r\n" + "Upper Floor : 1219 sq/ft\r\n";
                lblHomeSqrFeet.Text = "";
                lblHomeSqrFeet.Text = "4356";
            }
            else if (cmbHomePlan.Text == "The Family-Friendly Comfort => $400,000.00")
            {
                picbxHomeFront.Load("https://cdn.houseplansservices.com/product/87cf4blfrhrc608m3ibi0jtn1q/w800x533.jpg?v=11");
                picbxHomePlan.Load("https://cdn.houseplansservices.com/product/i9lga3t29bsqrro650fdrhhsk2/w600.jpg?v=12");
                rchtxtHousePlanInformation.Text = "";
                rchtxtHousePlanInformation.Text = "Bedrooms : 4\r\n" + "Stories: 2\r\n" + "Baths : 4.5\r\n" + "Garages: 3\r\n" + "Garage : 837 sq/ft\r\n" + "Main Floor : 1800 sq/ft\r\n" + "Upper Floor : 1086 sq/ft\r\n" + "Basement : 1800 sq/ft";
                lblHomeSqrFeet.Text = "";
                lblHomeSqrFeet.Text = "2886";
            }
            else if (cmbHomePlan.Text == "The Entertainer’s Dream => $800,000.00")
            {
                picbxHomeFront.Load("https://weberdesigngroup.com/wp-content/uploads/2016/12/contemporary-beach-home-plan-west-indies-style-878x586.jpg");
                picbxHomePlan.Load("https://weberdesigngroup.com/wp-content/uploads/2016/12/G1-4599-Abacoa-Model-FP-low-res-1.jpg");
                rchtxtHousePlanInformation.Text = "";
                rchtxtHousePlanInformation.Text = "Bedrooms : 4\r\n" + "Stories: 1\r\n" + "Baths : 4.5\r\n" + "Garages: 3\r\n" + "Garage : 1500 sq/ft\r\n" + "Main Floor : 2000 sq/ft\r\n" + "Upper Floor : 2000 sq/ft\r\n";
                lblHomeSqrFeet.Text = "";
                lblHomeSqrFeet.Text = "5500";
            }
            else if (cmbHomePlan.Text == "The Eco-Conscious Haven => $500,000.00")
            {
                picbxHomeFront.Load("https://cdn.houseplansservices.com/product/5lnbbed6p62ujqq57st6pvp4mk/w800x533.JPG?v=12");
                picbxHomePlan.Load("https://cdn.houseplansservices.com/product/gf4f3frc64entstc5g3ftm8js4/w600.JPG?v=11");
                rchtxtHousePlanInformation.Text = "";
                rchtxtHousePlanInformation.Text = "Bedrooms : 4\r\n" + "Stories: 2\r\n" + "Baths : 3\r\n" + "Garages: 2\r\n" + "Garage : 711 sq/ft\r\n" + "Main Floor : 2143 sq/ft\r\n" + "Upper Floor : 340 sq/ft\r\n" + "Porch : 256 sq/ft\r\n";
                lblHomeSqrFeet.Text = "";
                lblHomeSqrFeet.Text = "2483";
            }
            else if (cmbHomePlan.Text == "The Cozy Cottage => $1,000,000.00")
            {
                picbxHomeFront.Load("https://cdn.houseplansservices.com/product/gj4arn9gmq770vpkk1l8rulija/w800x533.jpg?v=12");
                picbxHomePlan.Load("https://cdn.houseplansservices.com/product/fq7srtlcccn1945ig5ci975a53/w600.jpg?v=10");
                rchtxtHousePlanInformation.Text = "";
                rchtxtHousePlanInformation.Text = "Bedrooms : 3\r\n" + "Stories: 2\r\n" + "Baths : 2.5\r\n" + "Garages: 2\r\n" + "Garage : 555 sq/ft\r\n" + "Main Floor : 1988 sq/ft\r\n" + "Porch : 493 sq/ft\r\n";
                lblHomeSqrFeet.Text = "";
                lblHomeSqrFeet.Text = "1988";
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void CheckStringTextValues(object sender, CancelEventArgs e)
        {
            double value = 0;

            TextBox control = (TextBox) sender;
            if (string.IsNullOrEmpty(control.Text))
            {
                MessageBox.Show("The " + control.Name + " cannot be blank");
                e.Cancel = true;
            }
            else if (double.TryParse(control.Text, out value))
            {
                MessageBox.Show("The " + control.Name + "must be letters");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }

        private void CheckDoubleTextValues(object sender, CancelEventArgs e)
        {
            double value = 0;
            TextBox control = (TextBox)sender;

            if (string.IsNullOrEmpty(control.Text))
            {
                MessageBox.Show("The " + control.Name + " cannot be blank");
                e.Cancel = true;
            } else if (!double.TryParse(control.Text, out value))
            {
                MessageBox.Show("The " + control.Name + "must be numerical numbers");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
            rdbnShingles.Checked = false;
            rdbnClayTiles.Checked = false;
            rdbnMetal.Checked = false;
            Home newHome = new Home();
            cmbHomePlan.DataSource = newHome.GetHomePlanOptions();
            cmbCountertopMaterial.DataSource = newHome.GetHomeCounterTopOptions();
            List<string> addOn = newHome.GetAddOnOptions();
            chklbAdditionalOptions.Items.AddRange(addOn.ToArray());
            rdbnShingles.Text = newHome.PopulateShinglesRoofOption(rdbnMetal.Text);
            rdbnClayTiles.Text = newHome.PopulateClayTilesRoofOption(rdbnClayTiles.Text);
            rdbnMetal.Text = newHome.PopulateMetalRoofOption(rdbnMetal.Text);
            chckTile.Text = newHome.PopulateTileFloorCoveringsOption(chckTile.Text);
            chckCarpet.Text = newHome.PopulateCarpetFloorCoveringsOption(chckCarpet.Text);
            chckWood.Text = newHome.PopulateWoodFloorCoveringsOption(chckWood.Text);
        }

        internal string GetSelectedItems(ArrayList slectedAddOns, CheckedListBox chklbAdditionalOptions)
        {
            string customerAddOns = "";

            if (chklbAdditionalOptions.CheckedItems.Count != 0)
            {
                for (int x = 0; x < chklbAdditionalOptions.CheckedItems.Count; x++)
                {
                    string itemText = chklbAdditionalOptions.CheckedItems[x].ToString();
                    string addOnName = "";

                    int index = itemText.IndexOf(" =>");

                    if (index != -1)
                    {
                        addOnName = itemText.Substring(0, index);
                    }

                    selectedAddOns.Add(addOnName);

                    customerAddOns += addOnName + ", ";
                }
            }
            return customerAddOns;
        }


        private bool FindingSelectedRoof()
        {
            if (rdbnShingles.Checked)
            {
                selectedRoofMaterial = rdbnShingles.Text;
                return true;
            }
            else if (rdbnMetal.Checked)
            {
                selectedRoofMaterial = rdbnMetal.Text;
                return true;
            }
            else if (rdbnClayTiles.Checked)
            {
                selectedRoofMaterial = rdbnClayTiles.Text;
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool FindingIfFloorMaterialsSelected()
        {
            if (chckTile.Checked || chckCarpet.Checked || chckWood.Checked)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /**
         * This event is used to find the selected the checkbox for floor material
         * and it updates the class variable selectedFloorMaterial with the checkbox Text
         * The if statements are worded this to only allow one checkbox to be checked.
         * If a user selects more than one checks more than one checkbox it will show a message
         * All the checkbox related to floor material are using this event
         */
        private void FindSelectedFloorMaterial(object sender, EventArgs e)
        {
                if (chckTile.Checked && !chckCarpet.Checked && !chckWood.Checked)
                {
                    selectedFloorMaterial = chckTile.Text;
                }
                else if (!chckTile.Checked && chckCarpet.Checked && !chckWood.Checked)
                {
                    selectedFloorMaterial = chckCarpet.Text;
                }
                else if (!chckTile.Checked && !chckCarpet.Checked && chckWood.Checked)
                {
                    selectedFloorMaterial = chckWood.Text;
                }
                else
                {
                    MessageBox.Show("Please you can only select one Floor Material");
                    selectedFloorMaterial = "";
                }

        }

        /**
         * This method finds the option which the user selected for his countertop material
         * All the combobox are using this event so any selected text from combobox will be sent to the selectedCountertopMaterial which is class variable
         */
        private void cmbCountertopMaterial_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedCountertopMaterial = cmbCountertopMaterial.SelectedItem.ToString();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            panel1.Visible = false;
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = true;
        }


        private void FindingSelectedRoof(object sender, CancelEventArgs e)
        {

        }

    }
}