﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeBuilder
{
    public class HomeBuyer
    {
        private string customerName;
        private string customerAddress;
        private double customerPhone;

        public HomeBuyer()
        {
            customerName = "";
            customerAddress = "";
            customerPhone = 0.00;
        }

        public HomeBuyer(string customerName, string customerAddress, double customerPhone)
        {
            this.customerName = customerName;
            this.customerAddress = customerAddress;
            this.customerPhone = customerPhone;
        }

        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }

        public string CustomerAddress
        {
            get { return customerAddress; }
            set { customerAddress = value; }
        }

        public double CustomerPhone
        {
            get { return customerPhone; }
            set { customerPhone = value; }
        }

        public override string ToString()
        {
            return "The customer Name is " + customerName + "\n"
                + "The customer Address is " + customerAddress + "\n"
                + "The cutsomer Phone Number is " + CustomerPhone + "\n";
        }
    }
}