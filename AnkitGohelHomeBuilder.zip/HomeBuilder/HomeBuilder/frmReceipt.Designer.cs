﻿namespace HomeBuilder
{
    partial class frmReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDate = new System.Windows.Forms.TextBox();
            this.rchtxtReciptInfo = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pcbxFrontRecipt = new System.Windows.Forms.PictureBox();
            this.pcbxPlanReceipt = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxFrontRecipt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxPlanReceipt)).BeginInit();
            this.SuspendLayout();
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(85, 101);
            this.txtDate.Name = "txtDate";
            this.txtDate.ReadOnly = true;
            this.txtDate.Size = new System.Drawing.Size(382, 20);
            this.txtDate.TabIndex = 0;
            // 
            // rchtxtReciptInfo
            // 
            this.rchtxtReciptInfo.Location = new System.Drawing.Point(12, 153);
            this.rchtxtReciptInfo.Name = "rchtxtReciptInfo";
            this.rchtxtReciptInfo.Size = new System.Drawing.Size(455, 379);
            this.rchtxtReciptInfo.TabIndex = 1;
            this.rchtxtReciptInfo.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Current Date";
            // 
            // pcbxFrontRecipt
            // 
            this.pcbxFrontRecipt.Location = new System.Drawing.Point(495, 53);
            this.pcbxFrontRecipt.Name = "pcbxFrontRecipt";
            this.pcbxFrontRecipt.Size = new System.Drawing.Size(512, 297);
            this.pcbxFrontRecipt.TabIndex = 3;
            this.pcbxFrontRecipt.TabStop = false;
            // 
            // pcbxPlanReceipt
            // 
            this.pcbxPlanReceipt.Location = new System.Drawing.Point(495, 379);
            this.pcbxPlanReceipt.Name = "pcbxPlanReceipt";
            this.pcbxPlanReceipt.Size = new System.Drawing.Size(512, 297);
            this.pcbxPlanReceipt.TabIndex = 4;
            this.pcbxPlanReceipt.TabStop = false;
            // 
            // frmReceipt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1163, 714);
            this.Controls.Add(this.pcbxPlanReceipt);
            this.Controls.Add(this.pcbxFrontRecipt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rchtxtReciptInfo);
            this.Controls.Add(this.txtDate);
            this.Name = "frmReceipt";
            this.Text = "frmReceipt";
            this.Load += new System.EventHandler(this.frmReceipt_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcbxFrontRecipt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxPlanReceipt)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox txtDate;
        internal System.Windows.Forms.RichTextBox rchtxtReciptInfo;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.PictureBox pcbxFrontRecipt;
        internal System.Windows.Forms.PictureBox pcbxPlanReceipt;
    }
}