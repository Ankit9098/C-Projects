﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeBuilder
{
    internal class Home
    {
        private string homePlan;
        private string homeRoofMaterial;
        private string homeCountertopMaterial;
        private string homeFloorCoverings;
        private Dictionary<string, double> homeAdditionalAddOns = new Dictionary<string, double>();
        private Dictionary<string, double> homePlanPrice = new Dictionary<string, double>();
        private Dictionary<string, double> homeRoofMaterialPrice = new Dictionary<string, double>();
        private Dictionary<string, double> homeCountertopMaterialPrice = new Dictionary<string, double>();
        private Dictionary<string, double> homeFloorCoveringsPrice = new Dictionary<string, double>();

        public Home()
        {
            homePlanPrice.Add("The Modern Minimalist", 300000.00);
            homePlanPrice.Add("The Family-Friendly Comfort", 400000.00);
            homePlanPrice.Add("The Entertainer’s Dream", 800000.00);
            homePlanPrice.Add("The Eco-Conscious Haven", 500000.00);
            homePlanPrice.Add("The Cozy Cottage", 1000000.00);

            homeRoofMaterialPrice.Add("Shingles", 13.75);
            homeRoofMaterialPrice.Add("Metal", 16.00);
            homeRoofMaterialPrice.Add("Clay Tiles", 24.00);

            homeCountertopMaterialPrice.Add("Formica", 2400.00);
            homeCountertopMaterialPrice.Add("Wood", 6000.00);
            homeCountertopMaterialPrice.Add("Granite", 4500.00);
            homeCountertopMaterialPrice.Add("Quartz", 2200.00);

            homeFloorCoveringsPrice.Add("Tile", 50.00);
            homeFloorCoveringsPrice.Add("Carpet", 2.50);
            homeFloorCoveringsPrice.Add("Wood", 7.80);

            homeAdditionalAddOns.Add("Finished Basement", 10000.00);
            homeAdditionalAddOns.Add("Pool", 30000.00);
            homeAdditionalAddOns.Add("Deck", 20000.00);
            homeAdditionalAddOns.Add("Fence", 1000.00);
            homeAdditionalAddOns.Add("Fireplace", 5000.00);
            homeAdditionalAddOns.Add("Hardwood Flooring", 8000.00);
            homeAdditionalAddOns.Add("Energy-Efficient Windows", 14000.00);
            homeAdditionalAddOns.Add("Solar Panels", 50000.00);
            homeAdditionalAddOns.Add("Smart Home Technology", 18000.00);
            homeAdditionalAddOns.Add("Landscaping", 10000.00);
        }

        public Home(string homePlan, string homeRoofMaterial, string homeCountertopMaterial, string homeFloorCoverings)
        {
            this.homePlan = homePlan;
            this.homeRoofMaterial = homeRoofMaterial;
            this.homeCountertopMaterial = homeCountertopMaterial;
            this.homeFloorCoverings = homeFloorCoverings;
            homePlanPrice.Add("The Modern Minimalist", 300000.00);
            homePlanPrice.Add("The Family-Friendly Comfort", 400000.00);
            homePlanPrice.Add("The Entertainer’s Dream", 800000.00);
            homePlanPrice.Add("The Eco-Conscious Haven", 500000.00);
            homePlanPrice.Add("The Cozy Cottage", 1000000.00);

            homeRoofMaterialPrice.Add("Shingles", 13.75);
            homeRoofMaterialPrice.Add("Metal", 16.00);
            homeRoofMaterialPrice.Add("Clay Tiles", 24.00);

            homeCountertopMaterialPrice.Add("Formica", 2400.00);
            homeCountertopMaterialPrice.Add("Wood", 6000.00);
            homeCountertopMaterialPrice.Add("Granite", 4500.00);
            homeCountertopMaterialPrice.Add("Quartz", 2200.00);

            homeFloorCoveringsPrice.Add("Tile", 50.00);
            homeFloorCoveringsPrice.Add("Carpet", 2.50);
            homeFloorCoveringsPrice.Add("Wood", 7.80);

            homeAdditionalAddOns.Add("Finished Basement", 10000.00);
            homeAdditionalAddOns.Add("Pool", 30000.00);
            homeAdditionalAddOns.Add("Deck", 20000.00);
            homeAdditionalAddOns.Add("Fence", 1000.00);
            homeAdditionalAddOns.Add("Fireplace", 5000.00);
            homeAdditionalAddOns.Add("Hardwood Flooring", 8000.00);
            homeAdditionalAddOns.Add("Energy-Efficient Windows", 14000.00);
            homeAdditionalAddOns.Add("Solar Panels", 50000.00);
            homeAdditionalAddOns.Add("Smart Home Technology", 18000.00);
            homeAdditionalAddOns.Add("Landscaping", 10000.00);
        }

        public string HomePlan
        {
            get { return homePlan; }
            set { homePlan = value; }
        }

        public string HomeRoofMaterial
        {
            get { return homeRoofMaterial; }
            set { homeRoofMaterial = value; }
        }

        public string HomeCountertopMaterial
        {
            get { return homeCountertopMaterial; }
            set { homeCountertopMaterial = value; }
        }

        public string HomeFloorCoverings
        {
            get { return homeFloorCoverings; }
            set { homeFloorCoverings = value; }
        }

        /*
         * This method return the cost of the HomePlan selected by the user
         * Arguments:
         *      string userSeelctedHomePlan = a home plan which the user selected in combobox
         * Return Value:
         *      double price - the cost of the home plan the user selected from the combox
         * Explanation: Sorry If it is confusing
         *      The value which is passed in this method will be something like combobox.selectedtext
         *      In these the selectedtext will look something like "The Modern Minimalist => $300,000.00"
         *      This input will cause an error if I try to use TryGetValue why? because my key in this is "The Modern Minimalist"
         *      The only other options I have to is to update the string with only "The Modern Minimalist"
         *      How will I acheive this simple => using the substring method to give me a new string which has my key.
         *      To use substring i need a start-index and length for the new string
         *      To find the length I first use IndexOf method to find where " =>" located so I can make this my length.
         *      Because my key is all the letters before " =>" I am able to create a new string with only the key that I can then find the cost from my dictionary.
         *      I am using the trim() method to remove whitespaces from the front and back of my new string.
         */
        public double GetHomePlanCost(string userSelectedHomePlan)
        {
            int index = userSelectedHomePlan.IndexOf(" =>");
            if (index != -1)
            {
                userSelectedHomePlan = userSelectedHomePlan.Substring(0, index).Trim();
            }

            if (homePlanPrice.TryGetValue(userSelectedHomePlan, out double price))
            {
                    return price; // Return the price if found.
            }
            return 0;
        }


        /*
         * This method return the cost of the Roof Material selected by the user
         * Arguments:
         *      string userSelectedHomeRoofMaterial = a home roof which the user selected in combobox
         *      homeSqrFeet = the sqr/ft of the home plan the user selected
         * Return Value:
         *      double price - the overall cost of the roof (this will be based on there homsqrft) the user selected from the combobox
         */
        public double GetHomeRoofCost(string userSelectedHomeRoofMaterial, double homeSqrFeet)
        {
            // First finidng the index of =>
            int index = userSelectedHomeRoofMaterial.IndexOf(" =>");
            // If the index is found
            if (index != -1)
            {
                // Using Substring method create a new string which starts from location 0 until the location of the index which will include the " =>"
                userSelectedHomeRoofMaterial = userSelectedHomeRoofMaterial.Substring(0, index).Trim();
            }
                // Finding the cost associated with the userselectedRoofMaterial this will find the value by using the key
            if (homeRoofMaterialPrice.TryGetValue(userSelectedHomeRoofMaterial, out double pricePerSquareFeet))
            {
                //Finding the total by using getting the cost of item and multipling it with the homeSqrFeet
                return pricePerSquareFeet * homeSqrFeet;
            }
            else
            {
                MessageBox.Show("Home Roof Material " + userSelectedHomeRoofMaterial + " not found.");
                return 0;
            }

        }

        /*
           * This method return the cost of the Countertop Material selected by the user
           * Arguments:
           *      string userSelectedHomeCountertopMaterial = a countertop material which the user selected.
           * Return Value:
           *      double price - the overall cost of the Countertop the user selected from the combobox
        */
        public double GetHomeCountertopMaterialPrice(string userSelectedHomeCountertopMaterial)
        {
            int index = userSelectedHomeCountertopMaterial.IndexOf(" =>");
            if (index != -1)
            {
                userSelectedHomeCountertopMaterial = userSelectedHomeCountertopMaterial.Substring(0,index).Trim();
            }
            if (homeCountertopMaterialPrice.TryGetValue(userSelectedHomeCountertopMaterial, out double price))
            {
                return price;
            }
            else
            {
                MessageBox.Show("Home Countertop Material " + userSelectedHomeCountertopMaterial + " not found.");
                return 0;
            }

            return 0;
        }

        /*
         * This method return the cost of the Roof Material selected by the user
         * Arguments:
         *      string userSelectedHomeRoofMaterial = a home roof which the user selected in combobox
         *      homeSqrFeet = the sqr/ft of the home plan the user selected
         * Return Value:
         *      double price - the overall cost of the roof (this will be based on there homsqrft) the user selected from the combobox
         */
        public double GetHomeFloorCoveringsCost(string userSelectedHomeFloorCoverings, double homeSqrFeet)
        {
            int index = userSelectedHomeFloorCoverings.IndexOf(" =>");
            if (index != -1)
            {
                userSelectedHomeFloorCoverings = userSelectedHomeFloorCoverings.Substring(0, index).Trim();
            }
            // Continue with the calculation using the extracted name
            if (homeFloorCoveringsPrice.TryGetValue(userSelectedHomeFloorCoverings, out double pricePerSquareFeet))
            {
                double totalCost = pricePerSquareFeet * homeSqrFeet;
                return totalCost;
            }
            else
            {
                MessageBox.Show("Home Floor Coverings " + userSelectedHomeFloorCoverings.ToString() + " not found.");
                return 0;
            }

            return 0;
        }

        /*
         * This method return a single string which will populate a checkbox for user selction
         * This is done because there are different radio buttons like rdbnShingles, rdbnMetal and so on..
         * I could only think of using this method because we had to implent MVC
         * Arguments:
         *      arrayList = This is an array of all the checked items which the user checked in the checkedlistBox
         * Return Value:
         *      total = The total cost of all the items the user slected in checkedlistbox
         * Explanation:
         *      Because a user can select multiple addons to find which speciifc items the users selected I created a ArrayList in the frmMain.cs
         *      Which gets all the checked text and adds them into an array. This method then using a for loop find the cost of items selcted one by one
         *      and finds the total cost.
         */

        public double GetAddOnPrice(ArrayList arrayList)
        {
            double totalCost = 0;

            for (int x = 0; x < arrayList.Count; x++)
            {
                string selectedAddOns = arrayList[x].ToString();
                if (homeAdditionalAddOns.TryGetValue(selectedAddOns, out double cost))
                {
                    totalCost += cost;
                }
            }
            return totalCost;
        }

         /*
            * This method return a List which will populate the combobox and various other gui options for user selction
            * Arguments:
            *
            * Return Value:
            *      generatePlan = That has a list of all the Key + "=>" Value of the homePlan Dictionary
        */
        public List<string> GetHomePlanOptions()
        {
            //Create a List that can be passed onto the combobox DataSource as String
            List<string> genratePlan = new List<string>();
            // Created a foreach method which uses KeyValuePair as a type to get all the key and values from my dictionary
            foreach (KeyValuePair<string, double> item in homePlanPrice)
            {
                // Create a temporary string variable so I can add them as a string in my List
                string temporaryValues = item.Key + " => " + item.Value.ToString("c");
                genratePlan.Add(temporaryValues);
            }
            // Sending the List
            return genratePlan;
        }

        /*
         * This method return a List which will populate the combobox and various other gui options for user selction
         * Arguments:
         *
         * Return Value:
         *      genrateCountertopOptions = That has a list of all the Key + "=>" Value of the countertop Dictionary
         */
        public List<string> GetHomeCounterTopOptions()
        {
            //Create a List that can be passed onto the combobox DataSource as String
            List<string> genrateCountertopOptions = new List<string>();
            // Created a foreach method which uses KeyValuePair as a type to get all the key and values from my dictionary
            foreach (KeyValuePair<string, double> item in homeCountertopMaterialPrice)
            {
                // Create a temporary string variable so I can add them as a string in my List
                string temporaryValues = item.Key + " => " + item.Value.ToString("c");
                genrateCountertopOptions.Add(temporaryValues);
            }
            // Sending the List
            return genrateCountertopOptions;
        }

        /*
         * This method return a List which will populate the checkedlistbox for user selction
         * Arguments:
         *
         * Return Value:
         *      genrateAddOnOptions = That has a list of all the Key + "=>" Value of the AddOn Dictionary
         */

        public List<string> GetAddOnOptions()
        {
            //Create a List that can be passed onto the combobox DataSource as String
            List<string> genrateAddOnOptions = new List<string>();
            // Created a foreach method which uses KeyValuePair as a type to get all the key and values from my dictionary
            foreach (KeyValuePair<string, double> item in homeAdditionalAddOns)
            {
                // Create a temporary string variable so I can add them as a string in my List
                string temporaryValues = item.Key + " => " + item.Value.ToString("c");
                genrateAddOnOptions.Add(temporaryValues);
            }
            // Sending the List
            return genrateAddOnOptions;
        }

        /*
         * This method return a single string which will populate a radiobutton for user selction
         * This is done because there are different radio buttons like rdbnShingles, rdbnMetal and so on..
         * I could only think of using this method because we had to implent MVC
         * Arguments:
         *
         * Return Value:
         *      roofMaterial = A new string with the Key + "=>" Value of the roofMaterial Dictionary
         */

        public string PopulateShinglesRoofOption(string roofMaterial)
        {
            roofMaterial = "Shingles";
            double cost = 0;
            homeRoofMaterialPrice.TryGetValue(roofMaterial, out cost);
            roofMaterial = roofMaterial + " => " + cost.ToString("c");
            return roofMaterial;
        }

        /*
           * This method return a single string which will populate a radiobutton for user selction
           * This is done because there are different radio buttons like rdbnShingles, rdbnMetal and so on..
           * I could only think of using this method because we had to implent MVC
           * Arguments:
           *
           * Return Value:
           *      roofMaterial = A new string with the Key + "=>" Value of the roofMaterial Dictionary
           */

        public string PopulateMetalRoofOption(string roofMaterial)
        {
            roofMaterial = "Metal";
            double cost = 0;
            homeRoofMaterialPrice.TryGetValue(roofMaterial, out cost);
            roofMaterial = roofMaterial + " => " + cost.ToString("c");
            return roofMaterial;
        }

        /*
           * This method return a single string which will populate a radiobutton for user selction
           * This is done because there are different radio buttons like rdbnShingles, rdbnMetal and so on..
           * I could only think of using this method because we had to implent MVC
           * Arguments:
           *
           * Return Value:
           *      roofMaterial = A new string with the Key + "=>" Value of the roofMaterial Dictionary
        */

        public string PopulateClayTilesRoofOption(string roofMaterial)
        {
            roofMaterial = "Clay Tiles";
            double cost = 0;
            homeRoofMaterialPrice.TryGetValue(roofMaterial, out cost);
            roofMaterial = roofMaterial + " => " + cost.ToString("c");
            return roofMaterial;
        }

        /*
         * This method return a single string which will populate a checkbox for user selction
         * This is done because there are different radio buttons like rdbnShingles, rdbnMetal and so on..
         * I could only think of using this method because we had to implent MVC
         * Arguments:
         *
         * Return Value:
         *      floorCoverings = A new string with the Key + "=>" Value of the roofMaterial Dictionary
         */
        public string PopulateTileFloorCoveringsOption(string floorCoverings)
        {
            floorCoverings = "Tile";
            double cost = 0;
            homeFloorCoveringsPrice.TryGetValue(floorCoverings, out cost);
            floorCoverings = floorCoverings + " => " + cost.ToString("c");
            return floorCoverings;
        }

        /*
         * This method return a single string which will populate a checkbox for user selction
         * This is done because there are different radio buttons like rdbnShingles, rdbnMetal and so on..
         * I could only think of using this method because we had to implent MVC
         * Arguments:
         *
         * Return Value:
         *      floorCoverings = A new string with the Key + "=>" Value of the roofMaterial Dictionary
         */
        public string PopulateCarpetFloorCoveringsOption(string floorCoverings)
        {
            floorCoverings = "Carpet";
            double cost = 0;
            homeFloorCoveringsPrice.TryGetValue(floorCoverings, out cost);
            floorCoverings = floorCoverings + " => " + cost.ToString("c");
            return floorCoverings;
        }

        /*
           * This method return a single string which will populate a checkbox for user selction
           * This is done because there are different radio buttons like rdbnShingles, rdbnMetal and so on..
           * I could only think of using this method because we had to implent MVC
           * Arguments:
           *
           * Return Value:
           *      floorCoverings = A new string with the Key + "=>" Value of the roofMaterial Dictionary
           */


        public string PopulateWoodFloorCoveringsOption(string floorCoverings)
        {
            floorCoverings = "Wood";
            double cost = 0;
            homeFloorCoveringsPrice.TryGetValue(floorCoverings, out cost);
            floorCoverings = floorCoverings + " => " + cost.ToString("c");
            return floorCoverings;
        }



    }
}