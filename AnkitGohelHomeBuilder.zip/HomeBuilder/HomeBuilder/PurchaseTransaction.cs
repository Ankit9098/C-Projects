﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeBuilder
{
    internal class PurchaseTransaction
    {
        /*
        string selectedHomeBuild = "";
        string selectedRoofMaterial = "";
        string selectedCountertopMaterial = "";
        string selectedFloorMaterial = "";
        double selectedHomeBuildCost = 0.00;
        double selectedRoofMaterialCost = 0.00;
        double selectedCountertopMaterialCost = 0.00;
        double selectedFloorMaterialCost = 0.00;
        double selectedAddOnsCost = 0.00;
        */

        private double customerBuildPrice;
        private double customerRoofMaterialPrice;
        private double customerKitchenCountertopMaterialPrice;
        private double customerFloorMaterialPrice;
        private double customerAddOnsPrice;
        private string customerHomeBuild;
        private string customerRoofMaterial;
        private string customerKitchenCountertopMaterial;
        private string customerFloorMaterial;
        private ArrayList customerAddOns;
        private double totalHomeCost;
        public string addOns;

        public PurchaseTransaction()
        {
        }

        public PurchaseTransaction(double customerBuildPrice, double customerRoofMaterialPrice, double customerKitchenCountertopMaterialPrice, double customerFloorMaterialPrice,
            double customerAddOnsPrice, string customerHomeBuild, string customerRoofMaterial, string customerKitchenCountertopMaterial, string customerFloorMaterial, ArrayList customerAddOns)
        {
            this.customerBuildPrice = customerBuildPrice;
            this.customerRoofMaterialPrice = customerRoofMaterialPrice;
            this.customerKitchenCountertopMaterialPrice = customerKitchenCountertopMaterialPrice;
            this.customerFloorMaterialPrice = customerFloorMaterialPrice;
            this.customerAddOnsPrice = customerAddOnsPrice;
            this.customerHomeBuild = customerHomeBuild;
            this.customerRoofMaterial = customerRoofMaterial;
            this.customerKitchenCountertopMaterial = customerKitchenCountertopMaterial;
            this.customerFloorMaterial = customerFloorMaterial;
            this.customerAddOns = new ArrayList(customerAddOns);
            totalHomeCost = 0.00;
            PrintingSelectedAddOns();
            CalculateTotalHomeCost();
        }

        public string CustomerHomeBuild
        {
            get { return customerHomeBuild; }
            set { customerHomeBuild = value; }
        }

        public string CustomerRoofMaterial
        {
            get { return customerRoofMaterial; }
            set { customerRoofMaterial = value; }
        }

        public string CustomerKitchenCountertopMaterial
        {
            get { return customerKitchenCountertopMaterial; }
            set { customerKitchenCountertopMaterial = value; }
        }

        public string CustomerFloorMaterial
        {
            get { return customerFloorMaterial; }
            set { customerFloorMaterial = value; }
        }

        public ArrayList CustomerAddOns
        {
            get { return customerAddOns; }
            set { customerAddOns = value; }
        }

        public double CustomerBuildPrice
        {
            get { return customerBuildPrice; }
            set { customerBuildPrice = value; }
        }

        public double CustomerRoofMaterialPrice
        {
            get { return customerRoofMaterialPrice; }
            set { customerRoofMaterialPrice = value; }
        }

        public double CustomerKitchenCountertopMaterialPrice
        {
            get { return customerKitchenCountertopMaterialPrice; }
            set { customerKitchenCountertopMaterialPrice = value; }
        }

        public double CustomerFloorMaterialPrice
        {
            get { return customerFloorMaterialPrice; }
            set { customerFloorMaterialPrice = value; }
        }

        public double CustomerAddOnsPrice
        {
            get { return customerAddOnsPrice; }
            set { customerAddOnsPrice = value; }
        }

        public double TotalHomeCost
        {
            get { return totalHomeCost; }
            set { totalHomeCost = value; }
        }

        public double CalculateTotalHomeCost()
        {
            totalHomeCost = customerBuildPrice + customerRoofMaterialPrice + customerKitchenCountertopMaterialPrice + customerFloorMaterialPrice + customerAddOnsPrice;
            return totalHomeCost;
        }

        public override string ToString()
        {
            return "Thank you\n" +
                    "Your Home Selection are as follows with there cost\n" +
                    "The Home Build you selected is " + customerHomeBuild +
                    " your cost for that build is " + customerBuildPrice.ToString("c") +
                    "\n" + "The roof material you selected for your Home is " + customerRoofMaterial + " your cost for that material is " + customerRoofMaterialPrice.ToString("c") + "\n" +
                    "The kitchen countertop material you selected for your Home is " + customerKitchenCountertopMaterial + " your cost for that material is " + customerKitchenCountertopMaterialPrice.ToString("c") + "\n" +
                    "The floor material you selected for your Home is " + customerFloorMaterial + " your cost for that material is " + customerFloorMaterialPrice.ToString("c") + "\n" +
                    "The Addons you selected are " + addOns + " there total cost is " + customerAddOnsPrice + "\n" +
                    "The total cost for your Home is " + totalHomeCost.ToString("c");
        }

        public void PrintingSelectedAddOns()
        {
            addOns = "";
            foreach (string item in customerAddOns)
            {
                addOns += item.ToString() + ", ";
            }
        }
    }
}